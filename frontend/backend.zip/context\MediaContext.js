// frontend/context/MediaContext.js
import { createContext, useState } from 'react';

export const MediaContext = createContext();

export const MediaProvider = ({ children }) => {
  const [currentMedia, setCurrentMedia] = useState(null);

  return (
    <MediaContext.Provider value={{ currentMedia, setCurrentMedia }}>
      {children}
    </MediaContext.Provider>
  );
};
