// src/aha/AHABCore.js
import React from 'react';
import useAHASync from './useAHASync';
import './aha.css';

export default function AHABCore() {
  useAHASync();

  return (
    <div className="aha-core">
      <h3>🔷 A.H.A.B. Neural Override Core</h3>
      <p>Adaptive Healing and Behavior layer is online.</p>
    </div>
  );
}
