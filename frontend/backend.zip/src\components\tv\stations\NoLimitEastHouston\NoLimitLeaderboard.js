import React, { useEffect, useState } from "react";
import { fetchLeaderboard } from "../../../utils/no-limit-api";
import styles from "./NoLimitStation.module.css";

export default function NoLimitLeaderboard() {
  const [leaders, setLeaders] = useState([]);

  useEffect(() => {
    fetchLeaderboard().then((data) => setLeaders(data || []));
  }, []);

  return (
    <div className={styles.leaderboard}>
      <h4>Top Supporters</h4>
      <ol>
        {leaders.map((l, i) => (
          <li key={i}>{l.name} – {l.tips} coins</li>
        ))}
      </ol>
    </div>
  );
}
