// frontend/src/configs/featureFlagsConfig.js
// Toggle PowerStream features ON/OFF without touching deep code

const FEATURE_FLAGS = {
  ENABLE_POWERFEED: true,     // Facebook-style feed
  ENABLE_POWERLINE: true,     // Messenger-style chat
  ENABLE_POWERREELS: true,    // TikTok-style short videos
  ENABLE_POWERGRAM: true,     // Instagram-style photos/stories
  ENABLE_TVSTATIONS: true,    // Live streaming TV
  ENABLE_PAYMENTS: true,      // Monetization
  ENABLE_AI_COPILOT: true,    // AI assistant
  ENABLE_VOICE_COMMANDS: true // Voice input/commands
};

export default FEATURE_FLAGS;
