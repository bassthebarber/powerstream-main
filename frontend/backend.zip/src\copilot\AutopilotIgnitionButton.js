// frontend/src/copilot/AutopilotIgnitionButton.js
import React, { useState } from "react";

const apiBase =
  import.meta.env.VITE_API_BASE ||
  process.env.REACT_APP_API_BASE ||
  "http://localhost:5001/api";

export default function AutopilotIgnitionButton() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const token = localStorage.getItem("token") || "";

  async function ignite() {
    setBusy(true);
    setMsg("");
    try {
      const res = await fetch(`${apiBase}/autopilot/ignite`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Autopilot failed");
      setMsg("✅ Autopilot completed");
    } catch (e) {
      setMsg(`❌ ${e.message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginTop: 12 }}>
      <button onClick={ignite} disabled={busy}>
        {busy ? "Running Autopilot…" : "Run Autopilot Builder Mode"}
      </button>
      {msg && <div style={{ marginTop: 8 }}>{msg}</div>}
    </div>
  );
}
