// frontend/components/MessageBubble.js
import React from 'react';

const MessageBubble = ({ message }) => {
  const isMine = message.isMine;

  return (
    <div className={`message-bubble ${isMine ? 'mine' : 'theirs'}`}>
      <div className="message-text">{message.text}</div>
      <div className="message-time">{message.timestamp}</div>
    </div>
  );
};

export default MessageBubble;
