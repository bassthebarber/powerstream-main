import React, { useState } from "react";
import styles from "./tgt.module.css";

export default function TGTTalentSearch() {
  const [query, setQuery] = useState("");

  const handleSearch = () => {
    alert(`Searching for talent: ${query}`);
  };

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>🔍 Search for Talent</h2>
      <input
        type="text"
        placeholder="Enter talent name..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ padding: "8px", width: "70%", marginRight: "10px" }}
      />
      <button className={styles.button} onClick={handleSearch}>Search</button>
    </div>
  );
}
