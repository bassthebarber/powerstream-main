// src/sovereign/SovereignCore.js
import React from 'react';
import useSovereignOverride from './useSovereignOverride';
import './sovereign.css';

export default function SovereignCore() {
  useSovereignOverride();

  return (
    <div className="sovereign-core">
      <h1>👑 Sovereign AI Control</h1>
      <p>All systems now report directly to the Sovereign Master.</p>
      <div className="sovereign-status">Status: Override Engaged</div>
    </div>
  );
}
