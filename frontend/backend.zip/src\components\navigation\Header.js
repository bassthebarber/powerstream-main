// components/Navigation/Header.js

import React from 'react';

const Header = () => {
  return (
    <header className="header">
      <h1>PowerStream</h1>
      <nav>
        <ul className="nav-links">
          <li><a href="/audio">Audio</a></li>
          <li><a href="/video">Video</a></li>
          <li><a href="/stream">Live</a></li>
          <li><a href="/feed">PowerFeed</a></li>
          <li><a href="/chat">PowerLine</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
