// src/copilot/InfinityInitialize.js
import axios from 'axios';

export function initializeInfinityCore() {
  return axios.post('/api/infinity/init')
    .then(res => {
      console.log("✅ Infinity Initialized", res.data);
      return res.data;
    })
    .catch(err => {
      console.error("🚨 Initialization Failed", err);
      throw err;
    });
}
