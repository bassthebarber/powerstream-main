// components/Navigation/Footer.js

import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <p>© {new Date().getFullYear()} PowerStream · All Rights Reserved</p>
      <div className="footer-links">
        <a href="/privacy">Privacy</a>
        <span>·</span>
        <a href="/terms">Terms</a>
        <span>·</span>
        <a href="/contact">Contact</a>
      </div>
    </footer>
  );
};

export default Footer;
