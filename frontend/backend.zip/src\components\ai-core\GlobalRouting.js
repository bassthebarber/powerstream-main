const GlobalRouting = {
  routes: {},

  register: function (intent, action) {
    this.routes[intent] = action;
  },

  handle: function (intent, payload) {
    if (this.routes[intent]) {
      this.routes[intent](payload);
    } else {
      console.warn(`No route found for intent: ${intent}`);
    }
  },
};

export default GlobalRouting;
