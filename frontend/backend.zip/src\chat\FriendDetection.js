// components/FriendDetection.js
import React, { useEffect, useState } from 'react';
import { getOnlineFriends } from '../utils/friendsApi';

export default function FriendDetection({ userId }) {
  const [friends, setFriends] = useState([]);

  useEffect(() => {
    if (!userId) return;
    const fetchFriends = async () => {
      try {
        const onlineFriends = await getOnlineFriends(userId);
        setFriends(onlineFriends);
      } catch (err) {
        console.error('Error fetching online friends:', err);
      }
    };

    fetchFriends();
    const interval = setInterval(fetchFriends, 10000); // refresh every 10s
    return () => clearInterval(interval);
  }, [userId]);

  return (
    <div className="friend-detection">
      <h4>Online Friends</h4>
      {friends.length > 0 ? (
        <ul>
          {friends.map(friend => (
            <li key={friend.id} className="friend-online">
              🟢 {friend.name}
            </li>
          ))}
        </ul>
      ) : (
        <p>No friends online</p>
      )}
    </div>
  );
}
