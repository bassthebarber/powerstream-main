// frontend/src/copilot/OverrideTrigger.js
import React, { useEffect } from "react";
import { socket } from "../utils/no-limit-socket";

export default function OverrideTrigger({ onOverride }) {
  useEffect(() => {
    socket.on("copilot:override:active", (data) => {
      console.log("Override activated at", new Date(data.at).toLocaleString());
      if (onOverride) onOverride();
    });

    return () => socket.off("copilot:override:active");
  }, [onOverride]);

  return null; // Pure logic component
}
