// useInfinityTrigger.js

import { useEffect, useState } from 'react';

export default function useInfinityTrigger(command) {
  const [response, setResponse] = useState(null);

  useEffect(() => {
    if (command) {
      console.log(`[INFINITY TRIGGER] Received: ${command}`);
      setResponse(`Triggered: ${command}`);
    }
  }, [command]);

  return response;
}
