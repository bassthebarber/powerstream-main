const CopilotCore = () => {
  return (
    <div>
      <h2>Copilot Core Online</h2>
      <p>Ready to receive input and assist.</p>
    </div>
  );
};

export default CopilotCore;
