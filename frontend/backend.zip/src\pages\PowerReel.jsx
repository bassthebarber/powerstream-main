import React from "react";
import { apiGet } from "../lib/api";

function Reel({ p }) {
  return (
    <div style={{ height: "92vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      {p.playbackUrl ? (
        <video
          src={p.playbackUrl}
          style={{ height: "100%", maxHeight: "92vh", borderRadius: 12 }}
          controls
          playsInline
          muted
          loop
          autoPlay
        />
      ) : p.mediaUrl ? (
        <img src={p.mediaUrl} alt="" style={{ maxHeight: "90vh", borderRadius: 12 }} />
      ) : (
        <div style={{ color: "#ddd" }}>{p.text}</div>
      )}
    </div>
  );
}

export default function PowerReel() {
  const [reels, setReels] = React.useState([]);
  const [cursor, setCursor] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const load = async (next=null) => {
    if (loading) return;
    setLoading(true); setError("");
    try {
      const qs = new URLSearchParams({ channel: "reel" });
      if (next) qs.set("cursor", next);
      const data = await apiGet(`/social/posts?${qs.toString()}`);
      setReels(prev => [...prev, ...(data.posts || [])]);
      setCursor(data.nextCursor || null);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => { load(); }, []);

  return (
    <div style={{ maxWidth: 520, margin: "0 auto" }}>
      <h2 style={{ color: "#d4af37", textAlign: "center" }}>PowerReel</h2>
      {reels.map(p => <Reel key={p._id || p.createdAt} p={p} />)}

      <div style={{ textAlign: "center", marginBottom: 16 }}>
        {cursor ? (
          <button onClick={() => load(cursor)} disabled={loading}
            style={{ padding: "8px 12px", borderRadius: 10, background: "#222", color: "#d4af37" }}>
            {loading ? "Loading…" : "Next"}
          </button>
        ) : (
          !loading && reels.length === 0 && <div style={{ color: "#888" }}>No reels.</div>
        )}
        {error && <div style={{ color: "#ff6b6b" }}>{error}</div>}
      </div>
    </div>
  );
}
