const GuardMode = () => {
  return (
    <div>
      <h2>Guard Mode Activated</h2>
      <p>Security protocols engaged. Monitoring system activity...</p>
    </div>
  );
};

export default GuardMode;
