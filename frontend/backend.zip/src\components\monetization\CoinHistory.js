// /components/monetization/CoinHistory.js
import React from 'react';

const CoinHistory = ({ history }) => {
  return (
    <div className="coin-history">
      <h4>Transaction History</h4>
      <ul>
        {history.map((tx, idx) => (
          <li key={idx}>{tx.date}: {tx.amount} 🪙 - {tx.type}</li>
        ))}
      </ul>
    </div>
  );
};

export default CoinHistory;
