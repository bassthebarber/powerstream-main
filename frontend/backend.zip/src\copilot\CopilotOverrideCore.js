// frontend/src/copilot/CopilotOverrideCore.js
import React, { useState, useEffect } from "react";

const apiBase =
  import.meta.env.VITE_API_BASE ||
  process.env.REACT_APP_API_BASE ||
  "http://localhost:5001/api";

export default function CopilotOverrideCore() {
  const [active, setActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const token = localStorage.getItem("token") || "";

  async function check() {
    try {
      const res = await fetch(`${apiBase}/copilot/override/state`, {
        headers: { Authorization: token ? `Bearer ${token}` : "" },
      });
      const data = await res.json();
      setActive(!!data.overrideActive);
    } catch {}
  }

  async function activate() {
    setBusy(true);
    try {
      const res = await fetch(`${apiBase}/copilot/override/activate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Activation failed");
      setActive(true);
    } catch (e) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    check();
  }, []);

  return (
    <div style={{ padding: 16, border: "1px dashed #555" }}>
      <h3>Copilot Override</h3>
      <p>Status: {active ? "🟢 ACTIVE" : "🔴 OFF"}</p>
      <button onClick={activate} disabled={busy || active}>
        {busy ? "Activating…" : "Activate Override"}
      </button>
    </div>
  );
}
