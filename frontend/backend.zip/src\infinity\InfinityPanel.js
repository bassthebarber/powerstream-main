// src/infinity/InfinityPanel.js
import React from 'react';
import CyberingDefenseGrid from '../cybering/CyberingDefenseGrid';
import AHABCore from '../aha/AHABCore';

export default function InfinityPanel() {
  return (
    <div>
      <h2>🚀 Infinity Core Panel</h2>
      <CyberingDefenseGrid />
      <AHABCore />
    </div>
  );
}
