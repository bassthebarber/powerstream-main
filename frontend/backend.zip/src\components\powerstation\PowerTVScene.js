// frontend/src/components/powerstation/PowerTVScene.js
import React from "react";
import styles from "./PowerStation.module.css";

export default function PowerTVScene() {
  return (
    <div className={styles.scene}>
      <h4>📺 PowerTV Scene</h4>
      <p>Live/TV layout rendering here...</p>
    </div>
  );
}
