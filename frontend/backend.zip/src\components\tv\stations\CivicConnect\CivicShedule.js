// CivicSchedule.js
import React, { useEffect, useState } from "react";
import styles from "./CivicModule.css";

export default function CivicSchedule() {
  const [schedule, setSchedule] = useState([]);

  useEffect(() => {
    // Fetch or mock civic broadcast schedule
    setSchedule([
      { time: "8:00 AM", title: "Morning Roundtable" },
      { time: "12:00 PM", title: "Policy Pulse" },
      { time: "5:00 PM", title: "City Spotlight" },
    ]);
  }, []);

  return (
    <div className={styles.container}>
      <h3 className={styles.label}>Broadcast Schedule</h3>
      <ul>
        {schedule.map((item, idx) => (
          <li key={idx}>
            <strong>{item.time}</strong> – {item.title}
          </li>
        ))}
      </ul>
    </div>
  );
}
