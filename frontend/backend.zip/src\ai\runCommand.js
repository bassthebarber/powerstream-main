// ai/runCommand.js
import { executeSystemCommand } from "./systemActions";
import { executePlatformCommand } from "./platformActions";

export default async function runCommand(command, params = {}) {
  console.log(`Running AI Command: ${command}`, params);

  try {
    // Try platform-level commands first (PowerStream-specific)
    const platformResult = await executePlatformCommand(command, params);
    if (platformResult) return platformResult;

    // Then try system-level commands
    const systemResult = await executeSystemCommand(command, params);
    if (systemResult) return systemResult;

    console.warn(`No handler found for command: ${command}`);
    return { status: "unknown-command", command };
  } catch (err) {
    console.error("Command execution failed:", err);
    return { status: "error", error: err.message };
  }
}
