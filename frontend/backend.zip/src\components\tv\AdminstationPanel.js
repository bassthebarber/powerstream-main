// components/TV/AdministrationPanel.js

import React from 'react';

const AdministrationPanel = () => {
  return (
    <div className="admin-panel">
      <h2>TV Station Administration Panel</h2>
      <p>Manage station settings, user access, and broadcast schedules.</p>
    </div>
  );
};

export default AdministrationPanel;
