// frontend/src/components/tv/stations/TexasGotTalent/TGTVoting.js
import React, { useState, useEffect } from "react";
import { io } from "socket.io-client";
import styles from "./tgt.module.css";

const socket = io("http://localhost:5000"); // Change if needed

export default function TGTVoting({ contestants }) {
  const [votes, setVotes] = useState({});

  useEffect(() => {
    socket.emit("joinTGT");

    socket.on("votingData", (data) => {
      setVotes(data || {});
    });

    return () => {
      socket.off("votingData");
    };
  }, []);

  const castVote = (id) => {
    socket.emit("vote", { contestantId: id });
  };

  const sorted = Object.entries(votes).sort((a, b) => b[1] - a[1]);

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>🏆 Live Voting & Leaderboard</h2>
      {contestants.map((c) => (
        <div key={c.id} style={{ marginBottom: "8px" }}>
          <button
            onClick={() => castVote(c.id)}
            className={styles.button}
          >
            Vote for {c.name}
          </button>
          <span style={{ marginLeft: "10px" }}>
            {votes[c.id] || 0} votes
          </span>
        </div>
      ))}
      <h3 style={{ marginTop: "20px" }}>Leaderboard</h3>
      <ul>
        {sorted.map(([id, count]) => {
          const c = contestants.find((x) => x.id === id);
          return (
            <li key={id}>
              {c ? c.name : id}: {count} votes
            </li>
          );
        })}
      </ul>
    </div>
  );
}
