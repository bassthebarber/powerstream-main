// frontend/components/stream/StreamPlayer.js
import React, { useRef, useEffect } from 'react';

export default function StreamPlayer({ streamUrl }) {
  const videoRef = useRef();

  useEffect(() => {
    if (videoRef.current && streamUrl) {
      videoRef.current.src = streamUrl;
    }
  }, [streamUrl]);

  return (
    <div className="stream-player">
      <video
        ref={videoRef}
        autoPlay
        controls
        playsInline
        style={{ width: '100%', borderRadius: '8px', background: '#000' }}
      />
    </div>
  );
}
