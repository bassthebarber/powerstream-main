import React from 'react';
import styles from '../styles/ReelsModule.css';

const Reels = ({ reels }) => {
  return (
    <div className={styles.reelsContainer}>
      <h2>PowerReels</h2>
      {reels.map((reel, index) => (
        <div key={index} className={styles.reel}>
          <video controls width="100%">
            <source src={reel.url} type="video/mp4" />
          </video>
          <p>{reel.caption}</p>
        </div>
      ))}
    </div>
  );
};

export default Reels;
