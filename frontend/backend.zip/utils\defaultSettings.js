// /frontend/utils/defaultSettings.js
const defaultSettings = {
  theme: 'dark',
  layout: 'power',
  streamQuality: 'HD',
};

export default defaultSettings;
