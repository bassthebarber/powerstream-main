// sockets/peerConnectionHandler.js
export const createPeerConnection = () => {
  const peerConnection = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  });

  peerConnection.onicecandidate = (event) => {
    if (event.candidate) {
      console.log("New ICE candidate:", event.candidate);
      if (window.onIceCandidate) {
        window.onIceCandidate(event.candidate);
      }
    }
  };

  peerConnection.ontrack = (event) => {
    console.log("Remote stream added");
    if (window.onRemoteStream) {
      window.onRemoteStream(event.streams[0]);
    }
  };

  return peerConnection;
};

export const addLocalStream = (peerConnection, stream) => {
  stream.getTracks().forEach((track) => {
    peerConnection.addTrack(track, stream);
  });
};

export const createOffer = async (peerConnection) => {
  const offer = await peerConnection.createOffer();
  await peerConnection.setLocalDescription(offer);
  return offer;
};

export const createAnswer = async (peerConnection, offer) => {
  await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await peerConnection.createAnswer();
  await peerConnection.setLocalDescription(answer);
  return answer;
};

export const setRemoteAnswer = async (peerConnection, answer) => {
  await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
};
