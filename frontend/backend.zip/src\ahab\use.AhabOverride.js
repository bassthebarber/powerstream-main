// useAhabOverride.js

import { useEffect, useState } from 'react';

export default function useAhabOverride() {
  const [override, setOverride] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setOverride(true);
      console.log('[AHAB OVERRIDE] Manual override is now active.');
    }, 2000);

    return () => clearTimeout(timeout);
  }, []);

  return override;
}
