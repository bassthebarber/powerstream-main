import React, { useState } from 'react';

const CommandInputBox = ({ onCommand }) => {
  const [input, setInput] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    onCommand(input);
    setInput('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Enter command"
        value={input}
        onChange={e => setInput(e.target.value)}
      />
      <button type="submit">Execute</button>
    </form>
  );
};

export default CommandInputBox;
