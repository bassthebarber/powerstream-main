// src/pages/PowerFeed.jsx
import { useEffect, useState } from 'react';
import api from '../lib/api';

export default function PowerFeed() {
  const [feed, setFeed] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        // Adjust the endpoint if your backend route differs
        const data = await api.get('/api/feed');
        const list = Array.isArray(data) ? data : (data?.items ?? []);
        if (active) setFeed(list);
      } catch (e) {
        if (active) setErr(e.message || 'Failed to load feed');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  if (loading) return <div>Loading feed…</div>;
  if (err) return <div style={{ color: 'red' }}>Error: {err}</div>;
  if (!feed.length) return <div>No items in the feed yet.</div>;

  return (
    <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
      {feed.map((item) => (
        <li key={item.id || item._id} style={{ borderBottom: '1px solid #eee', padding: '12px 0' }}>
          <strong>{item.title || item.name || 'Untitled'}</strong>
          {item.summary && <div style={{ color: '#555', marginTop: 6 }}>{item.summary}</div>}
        </li>
      ))}
    </ul>
  );
}
