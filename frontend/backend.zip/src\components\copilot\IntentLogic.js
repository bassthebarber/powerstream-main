const intentMap = {
  "play audio": () => console.log("Playing audio..."),
  "open feed": () => console.log("Opening PowerFeed..."),
  "start stream": () => console.log("Starting live stream...")
};

const handleIntent = (command) => {
  const action = intentMap[command.toLowerCase()];
  if (action) {
    action();
  } else {
    console.log("Unknown command:", command);
  }
};

export { handleIntent };
