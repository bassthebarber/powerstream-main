import React from "react";

const EULA_BODY = `LAST UPDATED: Aug 2025

This End-User License Agreement (“EULA”) is between you and PowerStream.
By clicking “I Agree” or using the app you accept this EULA.

1) License. We grant you a personal, non-transferable, revocable license to
use the app. All rights not expressly granted are reserved.

2) Content. You are responsible for the content you upload and you must have
the rights to it. We may remove content that violates law or our policies.

3) Prohibited Use. No unlawful, infringing, harassing, or automated scraping.
Do not attempt to bypass security or abuse the service.

4) Privacy. See our Privacy Policy (link in app) to learn how we process data.

5) Streaming. Live video may be recorded and stored to improve safety and
service operations.

6) Termination. We may suspend or terminate access for violations.

7) Warranty Disclaimer. THE APP IS PROVIDED “AS IS” WITHOUT WARRANTIES.

8) Limitation of Liability. To the maximum extent permitted by law, we are not
liable for indirect or consequential damages.

9) Changes. We may update this EULA by posting a new version in the app.

10) Contact. support@powerstream.example
`;

export default function EULA({ onAccept }) {
  const [accepted, setAccepted] = React.useState(
    localStorage.getItem("ps_eula_accepted") === "1"
  );

  const accept = () => {
    localStorage.setItem("ps_eula_accepted", "1");
    setAccepted(true);
    if (onAccept) onAccept(); // let App.jsx redirect
  };

  return (
    <div style={{ color: "#d4af37", padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1>PowerStream End-User License Agreement</h1>
      <div
        style={{
          whiteSpace: "pre-wrap",
          color: "#ddd",
          background: "#0f0f0f",
          border: "1px solid #333",
          borderRadius: 8,
          padding: 16,
          margin: "16px 0",
        }}
      >
        {EULA_BODY}
      </div>

      {!accepted ? (
        <button
          onClick={accept}
          style={{
            padding: "10px 16px",
            background: "#d4af37",
            color: "#000",
            fontWeight: 700,
            border: 0,
            borderRadius: 10,
            cursor: "pointer",
          }}
        >
          I Agree
        </button>
      ) : (
        <div style={{ color: "#9fdc9f" }}>
          Thanks — agreement saved. You can now use the app.
        </div>
      )}
    </div>
  );
}
