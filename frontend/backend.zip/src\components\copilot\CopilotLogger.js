// /components/copilot/copilotLogger.js

const CopilotLogger = {
  logs: [],

  log(message, level = 'info') {
    const entry = {
      timestamp: new Date().toISOString(),
      message,
      level,
    };
    this.logs.push(entry);
    if (process.env.NODE_ENV !== 'production') {
      console[level](entry);
    }
  },

  getLogs() {
    return this.logs;
  },

  clear() {
    this.logs = [];
  }
};

export default CopilotLogger;
