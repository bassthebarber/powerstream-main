import React, { useEffect, useState } from "react";
import { fetchNoLimitSchedule } from "../../../utils/no-limit-api";

export default function NoLimitSchedule() {
  const [schedule, setSchedule] = useState([]);

  useEffect(() => {
    fetchNoLimitSchedule().then((data) => setSchedule(data || []));
  }, []);

  return (
    <div>
      <h4>Upcoming Shows</h4>
      <ul>
        {schedule.map((s, i) => (
          <li key={i}>{s.time} - {s.title}</li>
        ))}
      </ul>
    </div>
  );
}
