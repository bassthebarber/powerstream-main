import { useState } from 'react';

const CopilotMemory = () => {
  const [memory, setMemory] = useState([]);

  const remember = (input) => {
    setMemory([...memory, input]);
  };

  return (
    <div>
      <h3>Copilot Memory</h3>
      <ul>
        {memory.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default CopilotMemory;
