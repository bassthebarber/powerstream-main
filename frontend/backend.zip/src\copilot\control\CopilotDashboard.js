// src/copilot/CopilotDashboard.js
import React from 'react';
import InfinityHUD from '../infinity/InfinityHUD';
import { triggerOverrideSequence } from './TriggerForceOverride';
import { initializeInfinityCore } from './InfinityInitialize';
import './ControlTower.css';

export default function CopilotDashboard() {
  return (
    <div className="control-tower-ui">
      <h2>🚨 Copilot Control Dashboard</h2>
      <InfinityHUD />
      <button onClick={initializeInfinityCore}>Initialize Infinity</button>
      <button onClick={triggerOverrideSequence}>Force Override</button>
    </div>
  );
}
