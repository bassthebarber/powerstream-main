import React from 'react';
import { Home, Users, Video, Heart, Menu } from 'lucide-react';
import Link from 'next/link';

const DockNavigation = () => {
  return (
    <nav className="fixed bottom-0 w-full bg-black text-gold flex justify-around py-3 z-50 border-t border-gold">
      <Link href="/feed">
        <div className="flex flex-col items-center">
          <Home size={24} />
          <span className="text-xs mt-1">Home</span>
        </div>
      </Link>
      <Link href="/friends">
        <div className="flex flex-col items-center">
          <Users size={24} />
          <span className="text-xs mt-1">Friends</span>
        </div>
      </Link>
      <Link href="/reels">
        <div className="flex flex-col items-center">
          <Video size={24} />
          <span className="text-xs mt-1">Reels</span>
        </div>
      </Link>
      <Link href="/notifications">
        <div className="flex flex-col items-center">
          <Heart size={24} />
          <span className="text-xs mt-1">Alerts</span>
        </div>
      </Link>
      <Link href="/menu">
        <div className="flex flex-col items-center">
          <Menu size={24} />
          <span className="text-xs mt-1">Menu</span>
        </div>
      </Link>
    </nav>
  );
};

export default DockNavigation;
