// ai/aiMemory.js

// Memory storage
let memoryStore = {};

// Load from localStorage if available
const loadMemory = () => {
  try {
    const saved = localStorage.getItem("aiMemory");
    if (saved) {
      memoryStore = JSON.parse(saved);
    }
  } catch (err) {
    console.error("Failed to load AI memory:", err);
  }
};

// Save to localStorage
const saveMemory = () => {
  try {
    localStorage.setItem("aiMemory", JSON.stringify(memoryStore));
  } catch (err) {
    console.error("Failed to save AI memory:", err);
  }
};

// Get a memory value
export const recall = (key) => {
  return memoryStore[key];
};

// Set a memory value
export const remember = (key, value) => {
  memoryStore[key] = value;
  saveMemory();
};

// Forget a memory value
export const forget = (key) => {
  delete memoryStore[key];
  saveMemory();
};

// Clear all memory
export const clearMemory = () => {
  memoryStore = {};
  saveMemory();
};

// Initialize
loadMemory();
console.log("AI Memory initialized:", memoryStore);
