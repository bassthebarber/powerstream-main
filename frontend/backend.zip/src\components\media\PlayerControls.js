// components/MediaPlayer/PlayerControls.js

import React from 'react';

const PlayerControls = ({ onPlay, onPause, onStop }) => {
  return (
    <div className="player-controls">
      <button onClick={onPlay}>▶️ Play</button>
      <button onClick={onPause}>⏸️ Pause</button>
      <button onClick={onStop}>⏹️ Stop</button>
    </div>
  );
};

export default PlayerControls;
