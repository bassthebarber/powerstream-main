const CopilotPanel = () => {
  return (
    <div className="copilot-panel">
      <h3>Copilot Command Panel</h3>
      <p>Status: Connected</p>
    </div>
  );
};

export default CopilotPanel;
