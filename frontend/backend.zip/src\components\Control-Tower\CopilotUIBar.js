import React from 'react';

const CopilotUIBar = ({ onActivate }) => {
  return (
    <div className="copilot-ui-bar">
      <button onClick={onActivate}>Activate CoPilot</button>
    </div>
  );
};

export default CopilotUIBar;
