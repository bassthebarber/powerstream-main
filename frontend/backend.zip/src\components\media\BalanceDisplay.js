// /components/monetization/BalanceDisplay.js
import React from 'react';

const BalanceDisplay = ({ coins }) => {
  return (
    <div className="balance-display">
      <h4>Your Coin Balance</h4>
      <p>{coins} 🪙</p>
    </div>
  );
};

export default BalanceDisplay;
