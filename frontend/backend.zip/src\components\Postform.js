import React, { useState } from 'react';
import axios from 'axios';
import styles from '../styles/feed.module.css';

const PostForm = ({ onPostCreated }) => {
  const [content, setContent] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;

    try {
      await axios.post('http://localhost:5001/api/feed', { content });
      setContent('');
      onPostCreated();
    } catch (err) {
      console.error('Error creating post:', err);
    }
  };

  return (
    <form onSubmit={handleSubmit} className={styles.postForm}>
      <textarea
        placeholder="What's going on in your world?"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className={styles.textarea}
      />
      <button type="submit" className={styles.postButton}>Post to PowerFeed</button>
    </form>
  );
};

export default PostForm;
