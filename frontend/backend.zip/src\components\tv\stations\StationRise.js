// frontend/src/components/tv/stations/StationRise.js
import React, { useState } from "react";

const apiBase =
  import.meta.env.VITE_API_BASE ||
  process.env.REACT_APP_API_BASE ||
  "http://localhost:5001/api";

export default function StationRise({ ownerId }) {
  const [stationName, setStationName] = useState("");
  const [layout, setLayout] = useState("powerfeed:auto");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function build() {
    setBusy(true);
    setMsg("");
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch(`${apiBase}/stations/build`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
        body: JSON.stringify({ ownerId, stationName, layout }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Build failed");
      setMsg(`✅ Built: ${data.station.name} (key: ${data.station.streamKey})`);
    } catch (e) {
      setMsg(`❌ ${e.message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ padding: 16, border: "1px solid #333", borderRadius: 8 }}>
      <h3>TV Station Builder</h3>
      <label>Name</label>
      <input
        value={stationName}
        onChange={(e) => setStationName(e.target.value)}
        placeholder="Station name"
      />
      <label style={{ marginTop: 8, display: "block" }}>Layout</label>
      <input value={layout} onChange={(e) => setLayout(e.target.value)} />
      <div style={{ marginTop: 12 }}>
        <button onClick={build} disabled={busy || !stationName}>
          {busy ? "Building…" : "Build Station"}
        </button>
      </div>
      {msg && <p style={{ marginTop: 8 }}>{msg}</p>}
    </div>
  );
}
