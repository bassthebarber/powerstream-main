import React, { useEffect, useState } from "react";
import styles from "./aistatuspanel.module.css";

export default function AIStatusPanel() {
  const [status, setStatus] = useState({
    "Infinity Core": "OFFLINE",
    "Override": "LOCKED",
    "Copilot": "OFFLINE"
  });

  const fetchStatus = async () => {
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/ai/status`);
      const data = await res.json();
      setStatus(data);
    } catch (err) {
      console.error("Error fetching AI status:", err);
    }
  };

  useEffect(() => {
    fetchStatus(); // First load
    const interval = setInterval(fetchStatus, 3000); // Every 3 seconds
    return () => clearInterval(interval);
  }, []);

  const renderStatus = (label, value) => {
    let className = styles.offline;
    if (value === "ONLINE" || value === "UNLOCKED" || value === "READY") {
      className = styles.online;
    }
    return (
      <div className={styles.statusRow}>
        <span className={styles.label}>{label}</span>
        <span className={`${styles.value} ${className}`}>{value}</span>
      </div>
    );
  };

  return (
    <div className={styles.panel}>
      <h2 className={styles.title}>🧠 PowerStream AI Status</h2>
      {renderStatus("Infinity Core", status["Infinity Core"])}
      {renderStatus("Override", status["Override"])}
      {renderStatus("Copilot", status["Copilot"])}
    </div>
  );
}
