import React from "react";
import { isAuthed } from "../lib/auth";
import { Navigate } from "react-router-dom";

export default function Protected({ children }) {
  return isAuthed() ? children : <Navigate to="/login" replace />;
}
