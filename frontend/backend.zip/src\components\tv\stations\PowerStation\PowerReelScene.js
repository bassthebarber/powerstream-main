// PowerReelsScene.js
import React, { useEffect, useRef, useState } from "react";
import styles from "./PowerStation.module.css";

export default function PowerReelsScene({ reels = [] }) {
  const [index, setIndex] = useState(0);
  const videoRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % reels.length);
    }, 10000); // change reel every 10 sec
    return () => clearInterval(interval);
  }, [reels.length]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.load();
    }
  }, [index]);

  const currentReel = reels[index] || {};

  return (
    <div className={styles.reelsScene}>
      <video
        ref={videoRef}
        key={currentReel._id}
        src={currentReel.url}
        autoPlay
        muted
        loop
        className={styles.reelVideo}
      />
      <div className={styles.overlay}>
        <h2 className={styles.reelTitle}>{currentReel.title || "Untitled Reel"}</h2>
        <p className={styles.reelUser}>By: @{currentReel.creator || "anonymous"}</p>
      </div>
    </div>
  );
}
