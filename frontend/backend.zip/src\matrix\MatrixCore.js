// src/matrix/MatrixCore.js
import React from 'react';
import MatrixGrid from './MatrixGrid';
import MatrixControl from './MatrixControl';
import './matrix.css';

export default function MatrixCore() {
  return (
    <div className="matrix-core">
      <MatrixControl />
      <MatrixGrid />
    </div>
  );
}
