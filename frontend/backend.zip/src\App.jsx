import React from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  NavLink,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";

// Your pages (make sure these exist)
import PowerFeed from "./pages/PowerFeed.jsx";
import PowerGram from "./pages/PowerGram.jsx";
import PowerReel from "./pages/PowerReel.jsx";
import TV from "./pages/TV.jsx";
import Login from "./pages/Login.jsx";
import EULA from "./pages/EULA.jsx";

const COLORS = { gold: "#d4af37", bg: "#0a0a0a", text: "#e6e6e6", dim: "#9aa0a6" };

// --- Guards ---
function useEulaAccepted() {
  return localStorage.getItem("ps_eula_accepted") === "1";
}
function EulaGuard({ children }) {
  const accepted = useEulaAccepted();
  const location = useLocation();
  if (!accepted && location.pathname !== "/eula") {
    return <Navigate to="/eula" state={{ from: location.pathname }} replace />;
  }
  return children;
}

// --- Chrome ---
function Header() {
  const linkStyle = ({ isActive }) => ({
    color: isActive ? COLORS.gold : COLORS.text,
    fontWeight: isActive ? 800 : 500,
    textDecoration: "none",
    padding: "8px 10px",
    borderRadius: 8,
    background: isActive ? "rgba(212,175,55,0.12)" : "transparent",
  });

  return (
    <header style={{ background: COLORS.bg, borderBottom: "1px solid #222", position: "sticky", top: 0, zIndex: 5 }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "10px 16px", display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{ color: COLORS.gold, fontWeight: 900 }}>PowerStream</div>
        <nav style={{ display: "flex", gap: 8 }}>
          <NavLink to="/feed" style={linkStyle}>Feed</NavLink>
          <NavLink to="/gram" style={linkStyle}>Gram</NavLink>
          <NavLink to="/reel" style={linkStyle}>Reel</NavLink>
          <NavLink to="/tv" style={linkStyle}>TV</NavLink>
          <NavLink to="/eula" style={linkStyle}>EULA</NavLink>
          <NavLink to="/login" style={linkStyle}>Login</NavLink>
        </nav>
      </div>
    </header>
  );
}
function Layout() {
  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, color: COLORS.text }}>
      <Header />
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: 16 }}>
        <Outlet />
      </main>
      <footer style={{ maxWidth: 1100, margin: "40px auto 20px", padding: "12px 16px", borderTop: "1px solid #222", color: COLORS.dim, fontSize: 12 }}>
        © PowerStream
      </footer>
    </div>
  );
}

// --- EULA wrapper: redirect back after accept ---
function EulaPageWithAutoRedirect() {
  const location = useLocation();
  const from = (location.state && location.state.from) || "/feed";
  const [accepted, setAccepted] = React.useState(localStorage.getItem("ps_eula_accepted") === "1");

  React.useEffect(() => {
    if (accepted) {
      const t = setTimeout(() => window.location.replace(from), 350);
      return () => clearTimeout(t);
    }
  }, [accepted, from]);

  const onAccept = () => {
    localStorage.setItem("ps_eula_accepted", "1");
    setAccepted(true);
  };

  return <EULA onAccept={onAccept} />;
}

// --- App routes ---
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* direct / to /feed */}
        <Route path="/" element={<Navigate to="/feed" replace />} />

        {/* public */}
        <Route path="/eula" element={<Layout />}>
          <Route index element={<EulaPageWithAutoRedirect />} />
        </Route>
        <Route path="/login" element={<Layout />}>
          <Route index element={<Login />} />
        </Route>

        {/* guarded by EULA */}
        <Route element={<EulaGuard><Layout /></EulaGuard>}>
          <Route path="/feed" element={<PowerFeed />} />
          <Route path="/gram" element={<PowerGram />} />
          <Route path="/reel" element={<PowerReel />} />
          <Route path="/tv" element={<TV />} />
        </Route>

        {/* 404 → feed */}
        <Route path="*" element={<Navigate to="/feed" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
