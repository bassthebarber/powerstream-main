// UseInfinity.js
import { useCallback } from 'react';
import { useInfinityCore } from './UseInfinityCore';
import { useInfinityTrigger } from './UseInfinityTrigger';

export default function useInfinity() {
  const { sendCommand, status, isOnline } = useInfinityCore();
  const { triggerOverride } = useInfinityTrigger();

  // Combined easy command runner
  const runInfinityCommand = useCallback((command, payload = {}) => {
    if (!isOnline) {
      console.warn("Infinity system is offline. Cannot run command:", command);
      return false;
    }
    sendCommand(command, payload);
    triggerOverride(command, payload);
    return true;
  }, [isOnline, sendCommand, triggerOverride]);

  return {
    runInfinityCommand,
    status,
    isOnline
  };
}
