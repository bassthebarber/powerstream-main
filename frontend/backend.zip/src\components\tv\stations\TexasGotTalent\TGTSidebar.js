// TGTSidebar.js
import React from "react";

export default function TGTSidebar({ onSelect }) {
  const items = ["Overview", "Leaderboard", "Live Chat", "Upload", "Schedule"];

  return (
    <div style={{ padding: 12, background: "#1a1a1a", borderRadius: 8 }}>
      <h4 style={{ color: "#eee" }}>Texas Got Talent</h4>
      <ul style={{ listStyle: "none", padding: 0 }}>
        {items.map((item) => (
          <li
            key={item}
            style={{
              padding: "8px 0",
              borderBottom: "1px solid #333",
              cursor: "pointer",
              color: "#00aaff",
            }}
            onClick={() => onSelect(item)}
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
