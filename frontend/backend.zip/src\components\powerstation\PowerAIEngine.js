// frontend/src/components/powerstation/PowerAIEngine.js
import { useEffect } from "react";

export default function PowerAIEngine({ onTrigger }) {
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Enter") {
        onTrigger("build:ai:station");
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onTrigger]);

  return null;
}
