// components/PlatformSwitcher.js

import React, { useState } from 'react';

const PlatformSwitcher = () => {
  const [platform, setPlatform] = useState('PowerStream');

  const handleSwitch = (newPlatform) => {
    setPlatform(newPlatform);
    console.log(`Switched to platform: ${newPlatform}`);
  };

  return (
    <div className="platform-switcher">
      <h3>Current Platform: {platform}</h3>
      <button onClick={() => handleSwitch('PowerStream')}>PowerStream</button>
      <button onClick={() => handleSwitch('PowerFeed')}>PowerFeed</button>
      <button onClick={() => handleSwitch('PowerLine')}>PowerLine</button>
      <button onClick={() => handleSwitch('TVGuide')}>TV Guide</button>
    </div>
  );
};

export default PlatformSwitcher;
