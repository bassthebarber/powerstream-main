import React from 'react';

const DefenseHUD = ({ alerts = [] }) => {
  return (
    <div className="bg-black text-white p-4 border border-red-500 rounded shadow">
      <h2 className="text-red-500 text-xl font-bold mb-2">Defense HUD</h2>
      {alerts.length === 0 ? (
        <p>No threats detected.</p>
      ) : (
        <ul className="list-disc pl-5">
          {alerts.map((alert, index) => (
            <li key={index} className="text-yellow-300">
              {alert}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DefenseHUD;
