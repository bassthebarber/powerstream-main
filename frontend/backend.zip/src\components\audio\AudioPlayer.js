const AudioPlayer = ({ title, artist, url }) => (
  <div style={{ margin: '10px 0' }}>
    <h4>{title} — {artist}</h4>
    <audio controls src={url} style={{ width: '100%' }} />
  </div>
);

export default AudioPlayer;
