// /components/hud/NeuralLinkPanel.js
import React from 'react';

const NeuralLinkPanel = () => {
  return (
    <div className="neural-link-panel">
      <h2>Neural Link Panel</h2>
      <p>Live connection established to the Copilot Neural Network.</p>
    </div>
  );
};

export default NeuralLinkPanel;
