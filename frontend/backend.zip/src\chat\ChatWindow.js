import React from "react";
import styles from "./privatechat.module.css";

export default function ChatWindow({ messages }) {
  return (
    <div className={styles.chatWindow}>
      {messages.length === 0 && (
        <p className={styles.noMessages}>No messages yet</p>
      )}
      {messages.map((msg, index) => (
        <div
          key={index}
          className={`${styles.message} ${
            msg.from === "me" ? styles.myMessage : styles.theirMessage
          }`}
        >
          <span>{msg.text}</span>
        </div>
      ))}
    </div>
  );
}
