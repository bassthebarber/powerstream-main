// /components/monetization/BuyCoinsPayPal.js
import React from 'react';

const BuyCoinsPayPal = ({ amount }) => {
  const handleBuy = () => {
    alert(`Buy ${amount} coins via PayPal - Coming Soon`);
  };

  return (
    <button onClick={handleBuy}>
      Buy {amount} Coins (PayPal)
    </button>
  );
};

export default BuyCoinsPayPal;
