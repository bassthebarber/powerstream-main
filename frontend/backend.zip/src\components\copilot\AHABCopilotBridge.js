// src/copilot/AHABCopilotBridge.js

import AHABCore from "../aha/AHABCore";
import AHABBridge from "../aha/AHABBridge";
import AHABLogger from "../aha/AHABLogger";
import AHABCommandMap from "../aha/AHABCommandMap";
import AHABSync from "../aha/AHABSync";
import AHABMasterSwitch from "../aha/AHABMasterSwitch";

const AHABCopilotBridge = {
  initializeAll: () => {
    AHABLogger.log("Initializing A-H-A-B to Copilot Bridge...");

    // Sync core systems
    AHABSync.syncCoreSystems();
    AHABBridge.linkWithCopilot();

    // Register A-H-A-B commands into Copilot
    AHABCommandMap.registerCommands();

    // Start override switch
    AHABMasterSwitch.activateOverride();

    // Connect main logic to Copilot Core
    AHABCore.injectIntoCopilot();

    AHABLogger.log("A-H-A-B is now fully connected to Copilot.");
  },

  triggerCommand(command) {
    AHABLogger.log(`Triggering AHAB command: ${command}`);
    AHABCommandMap.execute(command);
  },

  statusReport: () => {
    return {
      core: AHABCore.status(),
      sync: AHABSync.status(),
      override: AHABMasterSwitch.status(),
    };
  },
};

export default AHABCopilotBridge;
