import { io } from "socket.io-client";

const socket = io("http://localhost:5008", {
  path: "/socket.io"
});

export function subscribeToBuildProgress(callback) {
  socket.on("build:progress", (data) => {
    callback(data);
  });
}

export default socket;
