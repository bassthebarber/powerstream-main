import React, { useState } from 'react';
import axios from 'axios';

const CreatePost = ({ onPostCreated }) => {
  const [text, setText] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;

    try {
      const response = await axios.post('/api/posts', { text });
      onPostCreated(response.data);
      setText('');
    } catch (error) {
      console.error('Post creation failed', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-black text-white p-4 rounded shadow-md">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="What's going on in your world?"
        className="w-full p-2 bg-gray-800 text-white rounded mb-2"
      />
      <button type="submit" className="bg-gold text-black px-4 py-2 rounded hover:bg-yellow-500">
        Post to PowerFeed
      </button>
    </form>
  );
};

export default CreatePost;
