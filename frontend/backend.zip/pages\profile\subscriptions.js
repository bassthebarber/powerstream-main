// pages/subscriptions.js
import React from 'react';

export default function SubscriptionsPage() {
  return (
    <div className="subscriptions-page">
      <h1>Your Subscriptions</h1>
      <p>View and manage subscriptions to stations and streams.</p>
      {/* TODO: Connect to subscriptions API */}
    </div>
  );
}
