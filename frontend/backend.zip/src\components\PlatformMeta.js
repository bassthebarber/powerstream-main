// frontend/components/PlatformMeta.js

const PlatformMeta = {
  PowerFeed: {
    name: "PowerFeed",
    type: "Social Media",
    description: "Stream thoughts, posts, and community stories.",
    status: "Active",
    route: "/powerfeed"
  },
  PowerGram: {
    name: "PowerGram",
    type: "Short Video",
    description: "Scroll and share short creative videos.",
    status: "Launching Soon",
    route: "/powergram"
  },
  PowerLine: {
    name: "PowerLine",
    type: "Messaging",
    description: "Private and group messaging with AI support.",
    status: "Active",
    route: "/powerline"
  },
  PowerReels: {
    name: "PowerReels",
    type: "Streaming",
    description: "Upload and watch full-length videos and live shows.",
    status: "In Beta",
    route: "/reels"
  }
};

export default PlatformMeta;
