// pages/video/categories.js
import React from 'react';

export default function VideoCategories() {
  return (
    <div className="video-categories">
      <h1>Video Categories</h1>
      <p>Browse videos by genre or topic.</p>
      {/* TODO: Connect to /api/video/categories */}
    </div>
  );
}
