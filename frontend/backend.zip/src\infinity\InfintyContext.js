// InfinityContext.js
import React, { createContext, useContext, useState, useCallback } from 'react';
import useInfinity from './UseInfinity';

const InfinityContext = createContext();

export const InfinityProvider = ({ children }) => {
  const { runInfinityCommand, status, isOnline } = useInfinity();
  const [lastCommand, setLastCommand] = useState(null);
  const [systemLog, setSystemLog] = useState([]);

  const send = useCallback((cmd, payload = {}) => {
    setLastCommand({ cmd, payload, timestamp: Date.now() });
    setSystemLog(prev => [...prev, { cmd, payload, timestamp: new Date().toISOString() }]);
    runInfinityCommand(cmd, payload);
  }, [runInfinityCommand]);

  return (
    <InfinityContext.Provider
      value={{
        send,
        lastCommand,
        status,
        isOnline,
        systemLog
      }}
    >
      {children}
    </InfinityContext.Provider>
  );
};

export const useInfinityContext = () => useContext(InfinityContext);
