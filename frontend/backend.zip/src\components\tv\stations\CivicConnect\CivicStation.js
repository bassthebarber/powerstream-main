// CivicStation.js
import React, { useState } from "react";
import CivicSidebar from "./CivicSidebar";
import CivicPlayer from "./CivicPlayer";
import CivicSchedule from "./CivicSchedule";
import CivicCyborg from "./CivicCyborg";
import CivicUploadWidget from "./CivicUploadWidget";

export default function CivicStation() {
  const [view, setView] = useState("player");

  return (
    <div style={{ display: "flex", height: "100vh", background: "#111", color: "#fff" }}>
      <aside style={{ width: "20%", padding: "20px", background: "#1a1a1a" }}>
        <CivicSidebar onNavigate={setView} />
      </aside>

      <main style={{ flex: 1, padding: "20px", overflowY: "auto" }}>
        {view === "player" && <CivicPlayer streamUrl="http://localhost:5001/stream/civic" />}
        {view === "schedule" && <CivicSchedule />}
        {view === "cyborg" && <CivicCyborg />}
        {view === "upload" && <CivicUploadWidget />}
      </main>
    </div>
  );
}
