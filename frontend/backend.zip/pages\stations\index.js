// pages/stations/index.js
import React from 'react';

export default function StationsHome() {
  return (
    <div className="stations-home">
      <h1>All Stations</h1>
      <p>Browse and subscribe to stations.</p>
      {/* TODO: Connect to /api/stations */}
    </div>
  );
}
