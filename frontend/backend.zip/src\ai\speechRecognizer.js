// SpeechRecognizer.js
const startSpeechRecognition = (onCommandRecognized) => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    console.error("Speech Recognition API not supported in this browser.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  recognition.onstart = () => {
    console.log("🎙️ Voice recognition activated.");
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
  };

  recognition.onend = () => {
    console.log("🛑 Voice recognition stopped. Restarting...");
    recognition.start(); // Auto-restart for always-listening mode
  };

  recognition.onresult = (event) => {
    const transcript = event.results[event.results.length - 1][0].transcript.trim();
    console.log("🔊 Heard:", transcript);
    if (onCommandRecognized && typeof onCommandRecognized === 'function') {
      onCommandRecognized(transcript);
    }
  };

  recognition.start(); // Initial start
};

export default startSpeechRecognition;
