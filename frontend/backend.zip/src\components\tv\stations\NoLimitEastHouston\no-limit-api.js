const API_BASE =
  import.meta.env.VITE_API_BASE ||
  process.env.REACT_APP_API_BASE ||
  "http://localhost:5001/api";

export async function fetchNoLimitSchedule() {
  const res = await fetch(`${API_BASE}/nolimit/schedule`);
  return res.json();
}

export async function uploadNoLimitVideo(data, token) {
  const res = await fetch(`${API_BASE}/nolimit/upload`, {
    method: "POST",
    headers: {
      Authorization: token ? `Bearer ${token}` : "",
    },
    body: data,
  });
  return res.json();
}

export async function fetchLeaderboard() {
  const res = await fetch(`${API_BASE}/nolimit/leaderboard`);
  return res.json();
}
