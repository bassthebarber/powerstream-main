// frontend/config/env.config.js
const ENV = {
  API_BASE_URL: process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:5001/api",
  APP_NAME: "PowerStream",
};

export default ENV;
