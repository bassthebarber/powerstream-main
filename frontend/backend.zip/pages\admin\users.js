// pages/admin/users.js
import React from 'react';

export default function AdminUsers() {
  return (
    <div className="admin-users">
      <h1>Manage Users</h1>
      <p>View, ban, or promote users to moderators/admins.</p>
      {/* TODO: Connect to /api/admin/users */}
    </div>
  );
}
