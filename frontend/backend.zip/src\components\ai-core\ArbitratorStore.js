const ArbitratorStore = {
  state: {},
  set: function (key, value) {
    this.state[key] = value;
  },
  get: function (key) {
    return this.state[key];
  },
  clear: function () {
    this.state = {};
  },
};

export default ArbitratorStore;
