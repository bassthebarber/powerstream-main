// useAhabSync.js

import { useEffect, useState } from 'react';

export default function useAhabSync() {
  const [isSynced, setIsSynced] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsSynced(true);
      console.log('[AHAB SYNC] System successfully synced.');
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  return isSynced;
}
