// components/TV/AddBanner.js

import React, { useState } from 'react';

const AddBanner = ({ onSubmit }) => {
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [altText, setAltText] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const bannerData = {
      imageUrl,
      linkUrl,
      altText,
    };
    onSubmit(bannerData);
    setImageUrl('');
    setLinkUrl('');
    setAltText('');
  };

  return (
    <form className="add-banner-form" onSubmit={handleSubmit}>
      <h3>Add New Banner</h3>
      <input
        type="text"
        placeholder="Image URL"
        value={imageUrl}
        onChange={(e) => setImageUrl(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Link URL"
        value={linkUrl}
        onChange={(e) => setLinkUrl(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Alt Text"
        value={altText}
        onChange={(e) => setAltText(e.target.value)}
      />
      <button type="submit">Upload Banner</button>
    </form>
  );
};

export default AddBanner;
