// components/TV/AIVoicePlayer.js

import React, { useEffect } from 'react';

const AIVoicePlayer = ({ message }) => {
  useEffect(() => {
    if (window.speechSynthesis && message) {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.pitch = 1;
      utterance.rate = 1;
      window.speechSynthesis.speak(utterance);
    }
  }, [message]);

  return (
    <div className="voice-player">
      <p>🔊 {message}</p>
    </div>
  );
};

export default AIVoicePlayer;
