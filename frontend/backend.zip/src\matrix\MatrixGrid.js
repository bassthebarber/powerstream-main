// src/matrix/MatrixGrid.js
import React from 'react';

export default function MatrixGrid() {
  return (
    <div className="matrix-grid">
      {[...Array(16)].map((_, i) => (
        <div key={i} className="matrix-node">🧠</div>
      ))}
    </div>
  );
}
