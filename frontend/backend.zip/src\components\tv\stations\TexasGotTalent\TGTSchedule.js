import React from "react";
import styles from "./tgt.module.css";

export default function TGTSchedule() {
  const schedule = [
    { time: "6:00 PM", title: "Opening Auditions" },
    { time: "7:30 PM", title: "Live Performances" },
    { time: "9:00 PM", title: "Talent Showdown Finals" }
  ];

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>📅 Schedule</h2>
      <ul>
        {schedule.map((item, index) => (
          <li key={index}>
            <strong>{item.time}</strong> - {item.title}
          </li>
        ))}
      </ul>
    </div>
  );
}
