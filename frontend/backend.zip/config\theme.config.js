// frontend/config/theme.config.js
export const THEME = {
  primaryColor: '#FFD700',
  backgroundColor: '#000000',
  fontFamily: 'Helvetica, Arial, sans-serif',
  borderRadius: '6px',
};
