import React from 'react';

const FeatureShow = ({ title, description, thumbnail }) => {
  return (
    <div className="bg-black text-gold border border-gold rounded p-4 shadow-md">
      <img src={thumbnail} alt={title} className="w-full h-48 object-cover rounded mb-3" />
      <h3 className="text-xl font-semibold">{title}</h3>
      <p>{description}</p>
    </div>
  );
};

export default FeatureShow;
