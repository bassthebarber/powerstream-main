// frontend/components/ChatList.js
import React from 'react';

const ChatList = ({ chats, onSelect }) => {
  return (
    <div className="chat-list">
      {chats.map((chat, index) => (
        <div key={index} className="chat-list-item" onClick={() => onSelect(chat)}>
          {chat.name}
        </div>
      ))}
    </div>
  );
};

export default ChatList;
