import React from 'react';

const BrainOverridePanel = ({ onOverride, onReset }) => {
  return (
    <div className="override-panel">
      <h2>Override Brain System</h2>
      <button onClick={onOverride}>Engage Override</button>
      <button onClick={onReset}>Reset Brain</button>
    </div>
  );
};

export default BrainOverridePanel;
