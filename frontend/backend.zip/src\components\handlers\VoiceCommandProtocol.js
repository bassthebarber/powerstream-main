// /core/presentation/voiceCommandProtocol.js

const voiceCommandProtocol = {
  greet: () => "Welcome to PowerStream.",
  build: () => "Initializing system build...",
  status: () => "Copilot is online and functional.",
  fallback: () => "I'm sorry, I didn't catch that."
};

export default voiceCommandProtocol;
