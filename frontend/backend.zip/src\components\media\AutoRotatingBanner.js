// /components/media/AutoRotatingBanner.js
import React, { useEffect, useState } from 'react';

const banners = [
  "Welcome to PowerStream",
  "Stream Live. Go Global.",
  "Monetize Every View.",
  "Next-Gen TV Has Arrived"
];

const AutoRotatingBanner = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex(prev => (prev + 1) % banners.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="rotating-banner">
      <h1>{banners[index]}</h1>
    </div>
  );
};

export default AutoRotatingBanner;
