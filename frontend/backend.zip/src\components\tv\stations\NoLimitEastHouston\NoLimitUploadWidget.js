import React, { useState } from "react";
import { uploadNoLimitVideo } from "../../../utils/no-limit-api";

export default function NoLimitUploadWidget() {
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState("");

  const token = localStorage.getItem("token");

  async function upload() {
    if (!file) return;
    const data = new FormData();
    data.append("file", file);

    const result = await uploadNoLimitVideo(data, token);
    setMsg(result.ok ? "✅ Uploaded!" : "❌ Upload failed");
  }

  return (
    <div>
      <h4>Upload Video</h4>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={upload}>Upload</button>
      {msg && <p>{msg}</p>}
    </div>
  );
}
