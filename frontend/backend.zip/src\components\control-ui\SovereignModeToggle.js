import { useState } from 'react';

const SovereignModeToggle = () => {
  const [active, setActive] = useState(false);

  const toggleSovereign = () => {
    setActive(!active);
  };

  return (
    <div>
      <h3>Sovereign Mode: {active ? 'ON' : 'OFF'}</h3>
      <button onClick={toggleSovereign}>
        {active ? 'Deactivate' : 'Activate'}
      </button>
    </div>
  );
};

export default SovereignModeToggle;
