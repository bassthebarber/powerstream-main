import React, { useState } from "react";
import styles from "./tgt.module.css";

export default function TGTUploadWidget() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async () => {
    if (!file) return alert("Please select a file.");

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/texasgottalent/upload", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      alert("Upload successful!");
    } catch (err) {
      alert("Upload failed.");
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>⬆ Upload Talent Video</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button className={styles.button} onClick={handleUpload} disabled={uploading}>
        {uploading ? "Uploading..." : "Upload"}
      </button>
    </div>
  );
}
