import React from "react";
import styles from "./tgt.module.css";

export default function TGTCyborg() {
  return (
    <div className={styles.section}>
      <h2 className={styles.title}>🤖 AI Talent Recommender</h2>
      <p>The AI Cyborg is analyzing performance data in real-time...</p>
      <p>Recommendation system will be live during showtime.</p>
    </div>
  );
}
