// frontend/src/components/StationHeader.js
import React from 'react';

export default function StationHeader({ title }) {
  return (
    <header className="station-header">
      <h1>{title}</h1>
    </header>
  );
}
