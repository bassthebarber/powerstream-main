import { useEffect, useState } from 'react';

const CopilotLoader = () => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {loaded ? <p>Copilot Ready</p> : <p>Loading Copilot...</p>}
    </div>
  );
};

export default CopilotLoader;
