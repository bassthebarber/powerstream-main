// pages/video/manage.js
import React from 'react';

export default function ManageVideo() {
  return (
    <div className="manage-video">
      <h1>Manage Videos</h1>
      <p>View, edit, and delete uploaded videos.</p>
      {/* TODO: Connect to /api/video/manage */}
    </div>
  );
}
