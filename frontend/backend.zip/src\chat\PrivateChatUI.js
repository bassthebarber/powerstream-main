import React, { useState } from "react";
import PrivateChatEntry from "./PrivateChatEntry";
import StoryChatTrigger from "./StoryChatTrigger";
import VoiceInputChat from "./VoiceInputChat";
import ChatWindow from "./ChatWindow";
import styles from "./privatechat.module.css";

// Sample contacts (replace with backend fetch later)
const contacts = [
  { id: 1, name: "Jay Prince", avatar: "/default-avatar.png", lastMessage: "Let's go live!" },
  { id: 2, name: "Maya", avatar: "/default-avatar.png", lastMessage: "Check out my latest reel!" },
];

export default function PrivateChatUI() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);

  const handleSelectChat = (chat) => {
    setSelectedChat(chat);
    setMessages([]); // reset messages when switching chats
  };

  const handleSendMessage = (text) => {
    if (!text.trim()) return;
    setMessages((prev) => [...prev, { from: "me", text }]);
  };

  const handleStoryChat = () => {
    if (!selectedChat) return alert("Select a contact first!");
    alert(`Starting story chat with ${selectedChat.name}`);
  };

  return (
    <div className={styles.container}>
      {/* Contact List */}
      <div className={styles.sidebar}>
        <h3 className={styles.sidebarTitle}>Contacts</h3>
        {contacts.map((contact) => (
          <PrivateChatEntry
            key={contact.id}
            chat={contact}
            onSelect={handleSelectChat}
          />
        ))}
      </div>

      {/* Chat Section */}
      <div className={styles.chatSection}>
        {selectedChat ? (
          <>
            <div className={styles.chatHeader}>
              <img
                src={selectedChat.avatar}
                alt={selectedChat.name}
                className={styles.chatAvatar}
              />
              <h3>{selectedChat.name}</h3>
              <StoryChatTrigger onTrigger={handleStoryChat} />
            </div>
            <ChatWindow messages={messages} />
            <VoiceInputChat onSend={handleSendMessage} />
          </>
        ) : (
          <div className={styles.noChatSelected}>
            <p>Select a contact to start chatting</p>
          </div>
        )}
      </div>
    </div>
  );
}
