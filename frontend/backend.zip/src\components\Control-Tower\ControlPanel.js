import React from 'react';

const ControlPanel = ({ children }) => {
  return (
    <div className="control-panel">
      <h2>System Control Panel</h2>
      {children}
    </div>
  );
};

export default ControlPanel;
