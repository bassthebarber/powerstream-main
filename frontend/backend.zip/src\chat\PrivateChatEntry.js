import React from "react";
import styles from "./privatechatentry.module.css";

export default function PrivateChatEntry({ chat, onSelect }) {
  return (
    <div
      className={styles.entry}
      onClick={() => onSelect(chat)}
      role="button"
      tabIndex={0}
    >
      <img
        src={chat.avatar || "/default-avatar.png"}
        alt={chat.name}
        className={styles.avatar}
      />
      <div className={styles.info}>
        <span className={styles.name}>{chat.name}</span>
        <span className={styles.lastMessage}>{chat.lastMessage || "No messages yet"}</span>
      </div>
    </div>
  );
}
