// pages/feed.js
import React from 'react';
import HeaderBar from '../components/HeaderBar';
import BeCreativeBar from '../components/BeCreativeBar';
import StoryBar from '../components/BeCreativeStoryBar';
import PostForm from '../components/PostForm';
import FeedPost from '../components/FeedPost';
import PeopleYouMayKnow from '../components/PeopleYouMayKnow';
import styles from '../styles/PowerFeed.module.css';

const FeedPage = () => {
  return (
    <div className={styles.container}>
      <HeaderBar />
      <StoryBar />
      <BeCreativeBar />
      <PostForm />
      <div className={styles.feed}>
        <FeedPost />
        <FeedPost />
        <FeedPost />
      </div>
      <aside className={styles.sidebar}>
        <PeopleYouMayKnow />
      </aside>
    </div>
  );
};

export default FeedPage;
