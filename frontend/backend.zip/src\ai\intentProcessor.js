// IntentProcessor.js

import AhabIntentParser from '../utils/AhabIntentParser';
import InfinitySignalMapper from '../utils/InfinitySignalMapper';

class IntentProcessor {
  constructor() {
    this.intentLog = [];
  }

  async process(command, context = {}) {
    const parsedIntent = AhabIntentParser.parse(command);
    this.intentLog.push({ command, parsedIntent });

    const signal = InfinitySignalMapper.mapIntentToSignal(parsedIntent);

    if (signal && typeof signal.execute === 'function') {
      return await signal.execute(context);
    } else {
      throw new Error(`Unrecognized intent: "${parsedIntent.intent}"`);
    }
  }

  getLog() {
    return this.intentLog;
  }
}

export default new IntentProcessor();
