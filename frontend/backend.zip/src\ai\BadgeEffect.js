// frontend/src/components/ai/BadgeEffect.js
import React from "react";
import "./BadgeEffect.css";

export default function BadgeEffect({ label = "COPILOT MODE", show = true }) {
  if (!show) return null;

  return (
    <div className="badge-effect">
      <span className="pulse-glow">{label}</span>
    </div>
  );
}
