import React from "react";
import styles from "./NoLimitStation.module.css";

export default function NoLimitTVPlayer() {
  return (
    <div>
      <h2>NoLimit East Houston TV</h2>
      <video className={styles.video} controls autoPlay>
        <source src="/streams/nolimit-east.m3u8" type="application/x-mpegURL" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
}
