// src/infinity/InfinityBridge.js
import { initializeCore } from './InfinityCoreConnector';

export default function InfinityBridge() {
  initializeCore();
  return null;
}
