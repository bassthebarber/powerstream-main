// /components/copilot/copilotTerminalBridge.js

import React, { useEffect } from 'react';

const CopilotTerminalBridge = ({ command, onExecute }) => {
  useEffect(() => {
    if (command) {
      onExecute(command);
    }
  }, [command, onExecute]);

  return (
    <div className="terminal-bridge">
      <h4>Terminal Command Bridge Active</h4>
      <p>Last Command: {command}</p>
    </div>
  );
};

export default CopilotTerminalBridge;
