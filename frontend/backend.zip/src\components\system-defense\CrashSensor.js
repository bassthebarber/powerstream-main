import React from 'react';

const CrashSystem = ({ onRestart }) => {
  const simulateCrash = () => {
    if (window.confirm('Simulate system crash?')) {
      alert('💥 Crash simulated. System going down...');
      onRestart();
    }
  };

  return (
    <button
      onClick={simulateCrash}
      className="bg-black text-red-600 border border-red-600 px-4 py-2 rounded hover:bg-red-800 hover:text-white"
    >
      Simulate Crash
    </button>
  );
};

export default CrashSystem;
