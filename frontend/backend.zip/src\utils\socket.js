// Simple Socket.IO client wired to your backend origin
import { io } from "socket.io-client";

// Your API base ends with /api; strip it to get the server origin
const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:5001/api";
const SERVER_ORIGIN = API_BASE.replace(/\/api\/?$/, "");

export const socket = io(SERVER_ORIGIN, {
  path: "/socket.io",
  transports: ["websocket"],   // fastest; will fall back if needed
  autoConnect: true,
});

// Helpful logs
socket.on("connect",    () => console.log("✅ socket connected:", socket.id));
socket.on("disconnect", r  => console.log("❌ socket disconnected:", r));
socket.on("connect_error", e => console.log("⚠️ socket error:", e?.message));

// Tiny convenience API
export const on   = (event, fn)      => socket.on(event, fn);
export const off  = (event, fn)      => socket.off(event, fn);
export const emit = (event, payload) => socket.emit(event, payload);

export default socket;
