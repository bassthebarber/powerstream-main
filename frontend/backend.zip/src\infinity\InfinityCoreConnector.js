// src/infinity/InfinityCoreConnector.js
import axios from 'axios';

export function initializeCore() {
  axios.post('/api/infinity/init')
    .then(res => console.log('Infinity Core initialized:', res.data))
    .catch(err => console.error('Infinity Init Error', err));
}
