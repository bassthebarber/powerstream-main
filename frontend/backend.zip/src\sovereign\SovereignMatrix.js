// frontend/src/sovereign/SovereignMatrix.js
// High-security AI command processor for Sovereign Mode

import SovereignCommandMap from "../utils/infinity/SovereignCommandMap";
import InfinityTriggerMap from "../utils/infinity/InfinityTriggerMap";
import { activateFailsafe } from "../utils/infinity/InfinityFailsafe";

const SovereignMatrix = (command, actions = {}) => {
  if (!command || typeof command !== "string") {
    console.warn("SovereignMatrix: Invalid command input.");
    return;
  }

  const normalized = command.trim().toLowerCase();
  console.log(`🛡 SovereignMatrix received: "${normalized}"`);

  // Match against Sovereign Command Map
  const matchedCommand = Object.keys(SovereignCommandMap).find(
    (key) => key.toLowerCase() === normalized
  );

  if (matchedCommand) {
    const sovereignAction = SovereignCommandMap[matchedCommand];

    // If this command requires authentication, verify first
    if (sovereignAction().requiresAuth) {
      console.warn("🔒 SovereignMatrix: Command requires authentication.");
      // TODO: Implement voiceprint / passcode check here
    }

    // Execute the Sovereign action
    const actionResult = sovereignAction();
    console.log(`⚡ Executing Sovereign Action: ${matchedCommand}`, actionResult);

    // Special case: failsafe
    if (actionResult.type === "SHUTDOWN" || actionResult.type === "REBOOT_AI") {
      activateFailsafe();
    }

    // Route action through Infinity Trigger Map if needed
    InfinityTriggerMap(actionResult.type, actions);
    return;
  }

  console.warn(`SovereignMatrix: Command "${command}" not found in Sovereign Command Map.`);
};

export default SovereignMatrix;
