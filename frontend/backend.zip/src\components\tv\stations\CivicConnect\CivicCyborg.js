// CivicCyborg.js
import React, { useState } from "react";
import styles from "./CivicModule.css";

export default function CivicCyborg() {
  const [status, setStatus] = useState("Idle");
  const [busy, setBusy] = useState(false);

  const deployCyborg = () => {
    setBusy(true);
    setStatus("Activating Civic Intelligence…");
    setTimeout(() => {
      setStatus("🧠 CivicCyborg Online – Monitoring Civic Data");
      setBusy(false);
    }, 3000);
  };

  return (
    <div className={styles.container}>
      <h3 className={styles.label}>CivicCyborg Control</h3>
      <p className={styles.status}>{status}</p>
      <button className={styles.button} onClick={deployCyborg} disabled={busy}>
        {busy ? "Deploying…" : "Deploy CivicCyborg"}
      </button>
    </div>
  );
}
