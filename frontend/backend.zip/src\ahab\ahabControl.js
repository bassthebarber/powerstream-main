// AhabControl.js

import React, { useEffect, useState } from 'react';
import './AhabModule.css';
import useAhabOverride from './useAhabOverride';
import useAhabSync from './useAhabSync';

export default function AhabControl() {
  const override = useAhabOverride();
  const syncStatus = useAhabSync();
  const [status, setStatus] = useState('Initializing...');

  useEffect(() => {
    if (override && syncStatus) {
      setStatus('AHAB operational and synced.');
    }
  }, [override, syncStatus]);

  return (
    <div className="ahab-container">
      <div className="ahab-header">AHAB Control Panel</div>
      <div className="ahab-status">{status}</div>
    </div>
  );
}
