// pages/audio/playlist.js
import React from 'react';

export default function AudioPlaylist() {
  return (
    <div className="audio-playlist">
      <h1>Playlists</h1>
      <p>Create, edit, and listen to playlists.</p>
      {/* TODO: Connect to /api/audio/playlist */}
    </div>
  );
}
