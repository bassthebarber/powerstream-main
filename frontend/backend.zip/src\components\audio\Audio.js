import { useState } from 'react';
import axios from 'axios';

const AudioUploadForm = () => {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [url, setUrl] = useState('');

  const handleUpload = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/audio/upload', { title, artist, url });
      alert('Audio uploaded!');
    } catch (err) {
      alert('Upload failed');
    }
  };

  return (
    <form onSubmit={handleUpload}>
      <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Artist" value={artist} onChange={(e) => setArtist(e.target.value)} />
      <input placeholder="Audio URL" value={url} onChange={(e) => setUrl(e.target.value)} />
      <button type="submit">Upload Audio</button>
    </form>
  );
};

export default AudioUploadForm;
