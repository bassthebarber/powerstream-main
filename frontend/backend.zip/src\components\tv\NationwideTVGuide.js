// components/TV/NationalTVGuide.js

import React from 'react';

const NationalTVGuide = ({ stations }) => {
  return (
    <div className="national-tv-guide">
      <h2>📺 National TV Guide</h2>
      <ul>
        {stations.map((station, index) => (
          <li key={index}>
            <strong>{station.name}</strong> — {station.schedule}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NationalTVGuide;
