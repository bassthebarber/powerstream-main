// frontend/src/components/ai/core/controllers/AutoApprover.js
export function autoApproveContent(content) {
  const bannedWords = ["violence", "hate", "spam"];
  const flagged = bannedWords.some(word => content.toLowerCase().includes(word));
  return {
    approved: !flagged,
    reason: flagged ? "Contains restricted content" : "Clean",
  };
}
