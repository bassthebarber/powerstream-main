import React from 'react';

const PresidentialAlertButton = ({ onActivate }) => {
  const handleClick = () => {
    if (window.confirm('Are you sure you want to activate the Presidential Alert?')) {
      onActivate();
      alert('Presidential Alert has been activated.');
    }
  };

  return (
    <button
      onClick={handleClick}
      className="bg-red-600 hover:bg-red-800 text-white font-bold py-2 px-4 rounded"
    >
      🚨 Presidential Alert
    </button>
  );
};

export default PresidentialAlertButton;
