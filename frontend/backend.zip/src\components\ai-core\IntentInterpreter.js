import NeuralIntentMap from './NeuralIntentMap';

const IntentInterpreter = {
  interpret: function (command) {
    for (const intent in NeuralIntentMap) {
      const keywords = NeuralIntentMap[intent];
      for (const keyword of keywords) {
        if (command.toLowerCase().includes(keyword.toLowerCase())) {
          return intent;
        }
      }
    }
    return 'unknown';
  },
};

export default IntentInterpreter;
