import React from 'react';
import FeatureShow from './FeatureShow';

const shows = [
  {
    title: 'East Houston Spotlight',
    description: 'Live showcase of No Limit artists.',
    thumbnail: '/thumbnails/easthouston.jpg',
  },
  {
    title: 'Texas Talent Top Picks',
    description: 'Weekly highlights from Texas Got Talent.',
    thumbnail: '/thumbnails/texasstars.jpg',
  },
];

const FeatureShowcase = () => {
  return (
    <div className="bg-black text-white py-6 px-4">
      <h2 className="text-2xl text-gold font-bold mb-4">Featured Shows</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shows.map((show, idx) => (
          <FeatureShow key={idx} {...show} />
        ))}
      </div>
    </div>
  );
};

export default FeatureShowcase;
