import React, { useState } from "react";

const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:5001/api";

export default function NoLimitUpload() {
  const [kind, setKind] = useState("video"); // or "audio"
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState("");

  async function submit(e) {
    e.preventDefault();
    if (!file) { setStatus("Pick a file first."); return; }

    try {
      setStatus("Uploading…");
      const form = new FormData();
      form.append("channel", "no-limit-east-houston"); // backend tag
      form.append("kind", kind);                       // "audio" | "video"
      form.append("title", title);
      form.append("file", file);

      const res = await fetch(`${API_BASE}/upload`, { method: "POST", body: form });
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json.message || "Upload failed");
      setStatus("✅ Uploaded! Copilot can now style and wire this feed.");
    } catch (err) {
      setStatus(`❌ ${err.message}`);
    }
  }

  return (
    <div style={{ padding: 24, color: "#d4af37" }}>
      <h2>No Limit East Houston — Upload</h2>
      <p style={{ opacity: 0.85 }}>
        Choose audio or video. This posts to <code>/api/upload</code> with channel tag
        <code> no-limit-east-houston</code> so Copilot can auto-build a branded feed.
      </p>

      <form onSubmit={submit} style={{ display: "grid", gap: 12, maxWidth: 520 }}>
        <label>
          Type:
          <select value={kind} onChange={e => setKind(e.target.value)} style={{ marginLeft: 8 }}>
            <option value="video">Video (MP4, MOV)</option>
            <option value="audio">Audio (MP3, WAV)</option>
          </select>
        </label>

        <label>
          Title:
          <input
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="What is this?"
            style={{ width: "100%", padding: 8, borderRadius: 8, border: "1px solid #333", marginTop: 4 }}
          />
        </label>

        <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} />

        <button
          type="submit"
          style={{ padding: "10px 16px", background: "#d4af37", color: "#000", fontWeight: 700, border: 0, borderRadius: 10 }}
        >
          Upload
        </button>
      </form>

      {status && <div style={{ marginTop: 12 }}>{status}</div>}
    </div>
  );
}
