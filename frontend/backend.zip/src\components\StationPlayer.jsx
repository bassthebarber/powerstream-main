export default function StationPlayer({ src }) {
  return <video controls src={src} style={{ width: "100%", background: "#000" }} />;
}
