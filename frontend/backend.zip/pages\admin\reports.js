// pages/admin/reports.js
import React from 'react';

export default function AdminReports() {
  return (
    <div className="admin-reports">
      <h1>Reported Content</h1>
      <p>View and take action on reported videos, audio, or streams.</p>
      {/* TODO: Connect to /api/admin/reports */}
    </div>
  );
}
