import React, { useState, useEffect } from "react";
import styles from "./voiceinputchat.module.css";

export default function VoiceInputChat({ onSend }) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");

  let recognition;

  useEffect(() => {
    if ("webkitSpeechRecognition" in window) {
      recognition = new window.webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";

      recognition.onresult = (event) => {
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            setTranscript((prev) => prev + event.results[i][0].transcript + " ");
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const startListening = () => {
    if (recognition) {
      recognition.start();
      setIsListening(true);
    }
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
    }
  };

  const handleSend = () => {
    if (transcript.trim()) {
      onSend(transcript.trim());
      setTranscript("");
    }
  };

  return (
    <div className={styles.voiceContainer}>
      <button
        className={`${styles.micButton} ${isListening ? styles.listening : ""}`}
        onClick={isListening ? stopListening : startListening}
      >
        🎤
      </button>
      <input
        type="text"
        value={transcript}
        placeholder="Say something..."
        onChange={(e) => setTranscript(e.target.value)}
        className={styles.input}
      />
      <button className={styles.sendButton} onClick={handleSend}>
        ➤
      </button>
    </div>
  );
}
