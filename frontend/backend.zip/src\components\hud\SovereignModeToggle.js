// components/HUD/SovereignModeToggle.js
import React, { useState } from 'react';

export default function SovereignModeToggle() {
  const [enabled, setEnabled] = useState(false);

  const toggleMode = () => {
    setEnabled(!enabled);
    console.log(`Sovereign Mode ${!enabled ? 'Activated' : 'Deactivated'}`);
  };

  return (
    <div className="sovereign-toggle">
      <h2>Sovereign Mode</h2>
      <p>Status: <strong>{enabled ? 'Enabled' : 'Disabled'}</strong></p>
      <button onClick={toggleMode}>
        {enabled ? 'Deactivate' : 'Activate'}
      </button>
    </div>
  );
}
