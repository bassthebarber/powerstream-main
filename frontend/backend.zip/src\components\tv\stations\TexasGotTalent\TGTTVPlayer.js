import React from "react";
import styles from "./tgt.module.css";

export default function TGTTVPlayer() {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>🎬 Texas Got Talent Live</h1>
      <video
        className={styles.video}
        controls
        autoPlay
        muted
        src="rtmp://yourserver/texasgottalent"
      />
    </div>
  );
}
