import { connectBackend } from "./backendConnector";
import { initFrontendLayout } from "../components/CorePresentation";
import { buildAudioSection } from "../components/audio/AudioCore";
import { buildVideoSection } from "../components/film/FilmCore";
import { buildTVStations } from "../components/tv/TVStationHub";
import { buildPowerFeed } from "../feed/FeedMain";
import { buildPowerLine } from "../components/chat/ChatConnector";
import { buildPowerGram } from "../components/powergram/GramManager";
import { buildPowerReels } from "../components/reels/ReelsBuilder";
import { applyMTVTheme, applyNetflixTheme, applySpotifyTheme } from "../styles/themePresets";
import { activateVoiceAI } from "../voice/voiceCommandTrigger";
import { overrideWithSupremeCore } from "../system/SupremePowerstreamConnector";

export async function oneCommandEmpireBuild() {
  console.log("🧠 Initializing One-Command PowerStream Empire Build...");

  try {
    // 1. Backend & Frontend Sync
    await connectBackend();
    await initFrontendLayout();

    // 2. Core Feature Modules
    await buildPowerFeed();
    await buildPowerLine();
    await buildPowerGram();
    await buildPowerReels();
    await buildAudioSection();
    await buildVideoSection();
    await buildTVStations();

    // 3. Visual Theme Presets
    applyMTVTheme();        // MTV-style layout
    applyNetflixTheme();    // Netflix browsing UI
    applySpotifyTheme();    // Spotify-style music layout

    // 4. Voice + AI Build Commands
    activateVoiceAI(); // Listens for commands like: "Build PowerStream Empire"

    // 5. Global Override Core
    overrideWithSupremeCore();

    console.log("✅ PowerStream Empire Build Complete. System Operational.");
  } catch (error) {
    console.error("❌ Build Failed:", error);
  }
}
