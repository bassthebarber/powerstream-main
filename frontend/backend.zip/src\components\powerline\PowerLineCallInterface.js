import React, { useState } from 'react';
import styles from './PowerLineCallInterface.module.css';
import { VideoCallScreen } from './VideoCallScreen';
import { VoiceCallScreen } from './VoiceCallScreen';

const PowerLineCallInterface = () => {
  const [callType, setCallType] = useState(null);

  const handleStartVoiceCall = () => setCallType('voice');
  const handleStartVideoCall = () => setCallType('video');
  const handleEndCall = () => setCallType(null);

  return (
    <div className={styles.wrapper}>
      {!callType && (
        <div className={styles.launchPanel}>
          <h2>Launch a PowerLine Call</h2>
          <button onClick={handleStartVoiceCall} className={styles.voiceBtn}>Start Voice Call</button>
          <button onClick={handleStartVideoCall} className={styles.videoBtn}>Start Video Call</button>
        </div>
      )}
      {callType === 'voice' && <VoiceCallScreen onEndCall={handleEndCall} />}
      {callType === 'video' && <VideoCallScreen onEndCall={handleEndCall} />}
    </div>
  );
};

export default PowerLineCallInterface;
