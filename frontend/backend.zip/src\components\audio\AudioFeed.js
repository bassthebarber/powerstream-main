import { useEffect, useState } from 'react';
import axios from 'axios';
import AudioPlayer from './AudioPlayer';

const AudioFeed = () => {
  const [tracks, setTracks] = useState([]);

  useEffect(() => {
    axios.get('/api/audio/all').then((res) => setTracks(res.data));
  }, []);

  return (
    <div>
      <h2>🎧 Audio Feed</h2>
      {tracks.map((track) => (
        <AudioPlayer key={track._id} title={track.title} artist={track.artist} url={track.url} />
      ))}
    </div>
  );
};

export default AudioFeed;
