// src/infinity/InfinityOverrideStatus.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function InfinityOverrideStatus() {
  const [status, setStatus] = useState('Checking...');

  useEffect(() => {
    axios.get('/api/infinity/status')
      .then(res => setStatus(res.data.status))
      .catch(() => setStatus('Error'));
  }, []);

  return <div>Override Status: {status}</div>;
}
