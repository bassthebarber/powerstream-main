// frontend/src/components/ai/PowerRenderView.js
import React, { useState, useEffect } from "react";
import LogicEngine from "./core/controllers/LogicEngine";
import AlertEngine from "./core/controllers/AlertEngine";
import CoreBreathe from "./core/controllers/CoreBreathe";
import AutoApprover from "./core/controllers/AutoApprover";
import "./PowerStation.module.css";

export default function PowerRenderView() {
  const [command, setCommand] = useState("");
  const [response, setResponse] = useState("");
  const [history, setHistory] = useState([]);

  const handleCommand = async () => {
    if (!command.trim()) return;
    const output = await LogicEngine(command.trim());
    setHistory((h) => [...h, { input: command, output }]);
    setResponse(output);
    setCommand("");
  };

  useEffect(() => {
    CoreBreathe();       // Maintain AI state
    AutoApprover();      // Approve core system tasks
    AlertEngine("Power AI Online"); // Show live alert
  }, []);

  return (
    <div className="power-render-container">
      <h2>⚡ PowerStation AI View</h2>
      <input
        value={command}
        onChange={(e) => setCommand(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && handleCommand()}
        placeholder="Type a command (e.g., build powerfeed)"
        className="command-input"
      />
      <button onClick={handleCommand}>Send Command</button>
      <div className="response-view">{response}</div>
      <div className="command-history">
        {history.map((h, i) => (
          <div key={i} className="history-item">
            <b>> {h.input}</b>
            <pre>{h.output}</pre>
          </div>
        ))}
      </div>
    </div>
  );
}
