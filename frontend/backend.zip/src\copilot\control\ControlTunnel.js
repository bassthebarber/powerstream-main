// frontend/src/copilot/control/ControlTunnel.js
// Middleware for sending control commands to backend or other systems

const ControlTunnel = {
  sendCommand: async (command) => {
    try {
      const res = await fetch("/api/copilot/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command })
      });
      return await res.json();
    } catch (err) {
      console.error("ControlTunnel Error:", err);
      return null;
    }
  }
};

export default ControlTunnel;
