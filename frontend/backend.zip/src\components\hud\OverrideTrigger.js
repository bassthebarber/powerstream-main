// /core/hud/overrideTrigger.js

export const triggerOverride = () => {
  console.log("⚠️ System override manually triggered.");
  return {
    status: "override",
    message: "Manual override triggered by operator."
  };
};
