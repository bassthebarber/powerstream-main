const VoiceCommandProcessor = (transcript, intentMap, handleCommand) => {
  for (const [intent, triggers] of Object.entries(intentMap)) {
    for (const phrase of triggers) {
      if (transcript.toLowerCase().includes(phrase.toLowerCase())) {
        handleCommand(intent);
        return;
      }
    }
  }
};

export default VoiceCommandProcessor;
