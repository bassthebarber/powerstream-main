import React from "react";
import { NavLink, Link } from "react-router-dom";

export default function NavBar({ authed, onLogout }) {
  return (
    <div className="navbar">
      <div className="navbar-inner container">
        <div className="nav-left">
          <Link to="/" className="nav-link" style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <img className="logo-spin" src="/logos/powerstream-logo.png" alt="logo" />
            <b>PowerStream</b>
          </Link>
          <NavLink className="nav-link" to="/feed">Feed</NavLink>
          <NavLink className="nav-link" to="/gram">Gram</NavLink>
          <NavLink className="nav-link" to="/reel">Reel</NavLink>
          <NavLink className="nav-link" to="/tv">TV</NavLink>
          <NavLink className="nav-link" to="/copilot">Copilot</NavLink>
        </div>
        <div className="nav-right">
          {authed ? (
            <button onClick={onLogout}>Logout</button>
          ) : (
            <NavLink className="nav-link" to="/login">Login</NavLink>
          )}
        </div>
      </div>
    </div>
  );
}
