import React from 'react';
import styles from '../styles/feed.module.css';

const PostCard = ({ post }) => {
  return (
    <div className={styles.postCard}>
      <p className={styles.postContent}>{post.content}</p>
      <p className={styles.postDate}>
        {new Date(post.createdAt).toLocaleString()}
      </p>
    </div>
  );
};

export default PostCard;
