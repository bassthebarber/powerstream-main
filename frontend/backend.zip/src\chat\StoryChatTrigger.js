import React from "react";
import styles from "./storychattrigger.module.css";

export default function StoryChatTrigger({ onTrigger }) {
  return (
    <button className={styles.trigger} onClick={onTrigger}>
      💬 Start Story Chat
    </button>
  );
}
