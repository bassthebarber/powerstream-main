import React, { useEffect } from 'react';
import './ControlTower.css'; // Optional CSS styling file if needed
import { initializeAI } from '../../utils/aiCommandMap';
import { triggerPlatformSync } from '../../utils/platformMeta';
import { connectVoiceRecognition } from '../../utils/voiceRecognition';
import { masterOverride } from '../../core/BrainGlobalController';

const ControlTower = () => {
  useEffect(() => {
    console.log('🧠 ControlTower: Initializing AI Systems...');
    initializeAI();
    connectVoiceRecognition();
    triggerPlatformSync();
    masterOverride('PowerStream Supreme Initialization');
  }, []);

  return (
    <div className="control-tower">
      <h2>🛸 Control Tower Activated</h2>
      <p>PowerStream AI Sync now online.</p>
      <div className="sync-indicator">Status: ✅ Connected</div>
    </div>
  );
};

export default ControlTower;
