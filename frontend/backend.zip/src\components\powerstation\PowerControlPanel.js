// frontend/src/components/powerstation/PowerControlPanel.js
import React from "react";
import styles from "./PowerStation.module.css";

export default function PowerControlPanel() {
  return (
    <div className={styles.panel}>
      <h3>⚙️ AI Render Control</h3>
      <p>AI status: <span style={{ color: "lime" }}>READY</span></p>
    </div>
  );
}
