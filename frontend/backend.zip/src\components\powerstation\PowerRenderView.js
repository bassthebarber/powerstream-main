// frontend/src/components/ai/render/PowerRenderView.js
import React, { useRef, useState } from "react";
import { processContentAI } from "../core/controllers/LogicEngine";
import "./PowerStation.module.css";

export default function PowerRenderView() {
  const inputRef = useRef();
  const [input, setInput] = useState("");
  const [badge, setBadge] = useState("");

  const triggerAI = () => {
    const ok = processContentAI(input, inputRef);
    if (ok) setBadge("🧠 Copilot Activated");
    else setBadge("⚠️ Override Blocked");
  };

  return (
    <div className="power-render-wrap">
      <h2>🎬 Power Station Render View</h2>
      <textarea
        ref={inputRef}
        rows={4}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type AI command (e.g., Build TV, Launch Reels)..."
      />
      <div style={{ marginTop: 12 }}>
        <button onClick={triggerAI}>🔁 Run Copilot</button>
        {badge && <p style={{ marginTop: 8 }}>{badge}</p>}
      </div>
    </div>
  );
}
