import React from 'react';

const AdMibPanel = () => {
  return (
    <div className="ad-mib-panel">
      <h2>AdMib Control Panel</h2>
      <p>Monitor and control monetization ads from this dashboard.</p>
    </div>
  );
};

export default AdMibPanel;
