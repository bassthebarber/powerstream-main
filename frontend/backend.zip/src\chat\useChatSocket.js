// frontend/chat/useChatSocket.js
import { useEffect } from 'react';
import socket from '../utils/socket';
import { useChatContext } from './chat.context';

const useChatSocket = (userId) => {
  const { addMessage, setOnlineUsers } = useChatContext();

  useEffect(() => {
    if (!userId) return;

    socket.emit('user-online', userId);

    socket.on('receive-message', (message) => {
      addMessage(message);
    });

    socket.on('update-presence', ({ userId, isOnline }) => {
      setOnlineUsers(prev => ({
        ...prev,
        [userId]: isOnline,
      }));
    });

    return () => {
      socket.off('receive-message');
      socket.off('update-presence');
    };
  }, [userId]);
};

export default useChatSocket;
