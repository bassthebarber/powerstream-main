const ControlTerminalPanel = () => {
  return (
    <div className="terminal-panel">
      <h3>Control Terminal</h3>
      <textarea rows="10" cols="50" placeholder="Enter commands here..."></textarea>
    </div>
  );
};

export default ControlTerminalPanel;
