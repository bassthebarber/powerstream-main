// components/Navigation/Sidebar.js

import React from 'react';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="profile-section">
        <img src="/profile.jpg" alt="User" className="profile-pic" />
        <h3>Welcome Back</h3>
      </div>
      <ul className="sidebar-links">
        <li><a href="/dashboard">Dashboard</a></li>
        <li><a href="/stations">Stations</a></li>
        <li><a href="/tvguide">TV Guide</a></li>
        <li><a href="/upload">Upload</a></li>
        <li><a href="/support">Support</a></li>
      </ul>
    </aside>
  );
};

export default Sidebar;
