// components/TV/AIShowRecommender.js

import React from 'react';

const AIShowRecommender = ({ shows }) => {
  const recommended = shows.length > 0 ? shows[0] : null;

  return (
    <div className="ai-recommender">
      <h3>AI Recommended Show</h3>
      {recommended ? (
        <div>
          <h4>{recommended.title}</h4>
          <p>{recommended.description}</p>
        </div>
      ) : (
        <p>No recommendations available.</p>
      )}
    </div>
  );
};

export default AIShowRecommender;
