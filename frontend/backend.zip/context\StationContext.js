// /context/StationContext.js
import React, { createContext, useState, useContext, useEffect } from "react";
import { fetchStationData, updateStationSchedule, getStationAnalytics } from "../utils/station.api";

const StationContext = createContext();

export const StationProvider = ({ children }) => {
  const [stations, setStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState(null);
  const [schedule, setSchedule] = useState([]);
  const [analytics, setAnalytics] = useState({});
  const [loading, setLoading] = useState(false);

  // Fetch stations list
  const loadStations = async () => {
    setLoading(true);
    try {
      const data = await fetchStationData();
      setStations(data || []);
    } catch (error) {
      console.error("Error fetching stations:", error);
    } finally {
      setLoading(false);
    }
  };

  // Select a station and load its data
  const selectStation = async (stationId) => {
    setLoading(true);
    try {
      const station = stations.find((s) => s._id === stationId);
      setSelectedStation(station || null);
      if (station) {
        const sched = await updateStationSchedule(stationId);
        setSchedule(sched || []);
        const analyticsData = await getStationAnalytics(stationId);
        setAnalytics(analyticsData || {});
      }
    } catch (error) {
      console.error("Error loading station data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStations();
  }, []);

  return (
    <StationContext.Provider
      value={{
        stations,
        selectedStation,
        schedule,
        analytics,
        loading,
        selectStation,
        loadStations,
      }}
    >
      {children}
    </StationContext.Provider>
  );
};

export const useStation = () => useContext(StationContext);
n  