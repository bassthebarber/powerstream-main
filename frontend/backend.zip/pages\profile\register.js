import React, { useState } from "react";
import styles from "./register.module.css";

export default function ProfileRegister() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Registering:", form);
    // TODO: call /api/auth/register
  };

  return (
    <div className={styles.container}>
      <h2>Register for Funny & Paige's Profile</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <input name="name" placeholder="Full Name" value={form.name} onChange={handleChange} />
        <input name="email" placeholder="Email" value={form.email} onChange={handleChange} />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} />
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
