// AlertEngine.js
export default function AlertEngine(msg = "AI Copilot Online") {
  const alert = document.createElement("div");
  alert.className = "ai-alert-badge";
  alert.innerText = msg;
  document.body.appendChild(alert);
  setTimeout(() => document.body.removeChild(alert), 3000);
}
