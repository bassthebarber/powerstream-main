// InfinityOverride.js

import InfinityCore from './InfinityCore';

const core = new InfinityCore();

export function overrideCommand(input) {
  console.warn('[OVERRIDE] Manual override triggered:', input);
  if (input === 'shutdown') return core.shutdown();
  if (input === 'boot') return core.boot();
  return `[OVERRIDE] No handler for command: ${input}`;
}
