// /components/copilot/copilotBridge.js

import React from 'react';

const CopilotBridge = ({ status, message }) => {
  return (
    <div className="copilot-bridge">
      <h3>Copilot Bridge</h3>
      <p>Status: {status}</p>
      <p>Message: {message}</p>
    </div>
  );
};

export default CopilotBridge;
