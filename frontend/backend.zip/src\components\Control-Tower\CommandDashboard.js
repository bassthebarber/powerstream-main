import React from 'react';

const CommandDashboard = ({ commands }) => {
  return (
    <div className="command-dashboard">
      <h2>Command Center</h2>
      <ul>
        {commands.map((cmd, i) => (
          <li key={i}>{cmd}</li>
        ))}
      </ul>
    </div>
  );
};

export default CommandDashboard;
