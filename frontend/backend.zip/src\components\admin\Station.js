import React from 'react';

const Station = () => {
  return (
    <div>
      <h1>Station Dashboard</h1>
      <p>Manage station scheduling, content, and override systems.</p>
    </div>
  );
};

export default Station;
