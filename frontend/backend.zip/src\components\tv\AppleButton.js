// components/TV/AppleButton.js

import React from 'react';

const AppleButton = ({ onClick }) => {
  return (
    <button className="apple-button" onClick={onClick}>
      🍎 Buy with Apple Pay
    </button>
  );
};

export default AppleButton;
