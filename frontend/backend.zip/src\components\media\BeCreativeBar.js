// /components/media/BeCreativeBar.js
import React from 'react';

const BeCreativeBar = () => {
  return (
    <div className="be-creative-bar">
      <input type="text" placeholder="What's going on in your world?" />
      <button>Post</button>
    </div>
  );
};

export default BeCreativeBar;
