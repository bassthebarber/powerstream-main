// /components/media/BeCreativeStoryBar.js
import React from 'react';

const BeCreativeStoryBar = () => {
  return (
    <div className="be-creative-story-bar">
      <div className="story-card">+ Add to Story</div>
      {/* Story thumbnails would go here */}
    </div>
  );
};

export default BeCreativeStoryBar;
