// pages/notifications.js
import React from 'react';

export default function NotificationsPage() {
  return (
    <div className="notifications-page">
      <h1>Notifications</h1>
      <p>Your latest alerts and updates.</p>
      {/* TODO: Connect to notifications API */}
    </div>
  );
}
