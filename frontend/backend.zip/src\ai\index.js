// /src/AI/index.js
import SpeechRecognizer from './speechRecognizer';
import IntentProcessor from './intentProcessor';
import VoiceIntentMapper from './voiceIntentMapper';

let isAIActive = false;
let recognitionInstance = null;

function initAI() {
  if (isAIActive) return;
  isAIActive = true;

  console.log("🧠 [AI] PowerStream AI initializing...");

  // Start listening immediately
  startSpeechRecognition();

  // Auto-restart every 10 minutes just to ensure uptime
  setInterval(() => {
    if (!isAIActive) return;
    console.log("🔄 [AI] Auto-restarting speech recognizer for stability...");
    restartSpeechRecognition();
  }, 10 * 60 * 1000);
}

function startSpeechRecognition() {
  recognitionInstance = SpeechRecognizer((spokenText) => {
    console.log(`🎙️ [SpeechRecognizer] Heard: "${spokenText}"`);
    const intent = VoiceIntentMapper(spokenText);
    if (intent) {
      console.log(`🧭 [AI] Mapped to intent: ${intent}`);
      IntentProcessor(intent);
    } else {
      console.warn(`⚠️ [AI] No intent mapping found for: "${spokenText}"`);
    }
  });

  if (recognitionInstance && recognitionInstance.start) {
    try {
      recognitionInstance.start();
      console.log("🎧 [AI] Listening for commands...");
    } catch (err) {
      console.error("❌ [AI] Could not start recognition:", err);
    }
  }
}

function restartSpeechRecognition() {
  try {
    if (recognitionInstance && recognitionInstance.stop) {
      recognitionInstance.stop();
    }
  } catch (e) {}
  startSpeechRecognition();
}

// Automatically start when app loads
document.addEventListener("DOMContentLoaded", () => {
  console.log("🚀 [AI] Auto-starting PowerStream AI on load...");
  initAI();
});

export default {
  initAI,
  restartSpeechRecognition
};
