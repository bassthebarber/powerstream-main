const CopilotBridge = ({ sendCommand }) => {
  return (
    <div>
      <button onClick={() => sendCommand('Activate Bridge')}>
        Bridge Command
      </button>
    </div>
  );
};

export default CopilotBridge;
