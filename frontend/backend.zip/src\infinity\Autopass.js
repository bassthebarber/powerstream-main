// Autopass.js
import { useEffect } from 'react';
import useInfinity from './UseInfinity';

export default function Autopass({ commands = [] }) {
  const { runInfinityCommand, isOnline } = useInfinity();

  useEffect(() => {
    if (!isOnline || commands.length === 0) return;

    console.log("🚀 [Autopass] Auto-executing priority commands...");
    commands.forEach(cmd => {
      if (typeof cmd === 'string') {
        runInfinityCommand(cmd);
      } else if (cmd && cmd.name) {
        runInfinityCommand(cmd.name, cmd.payload || {});
      }
    });
  }, [isOnline, commands, runInfinityCommand]);

  return null; // Headless component
}
