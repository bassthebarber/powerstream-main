// components/SystemDefense/FailSafeSwitch.js

import React, { useState } from 'react';

const FailSafeSwitch = () => {
  const [activated, setActivated] = useState(false);

  const toggleFailsafe = () => {
    setActivated(!activated);
    alert(activated ? 'Failsafe Deactivated' : 'Failsafe Activated: Override Engaged');
  };

  return (
    <div className="failsafe-panel">
      <h3>FailSafe Emergency Switch</h3>
      <p>System Override: {activated ? 'ON' : 'OFF'}</p>
      <button onClick={toggleFailsafe}>
        {activated ? 'Deactivate' : 'Activate'}
      </button>
    </div>
  );
};

export default FailSafeSwitch;
