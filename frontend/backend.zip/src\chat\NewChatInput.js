// frontend/chat/NewChatInput.js
import React, { useState } from 'react';
import socket from '../utils/socket';

const NewChatInput = ({ senderId, roomId }) => {
  const [input, setInput] = useState('');

  const send = () => {
    if (input.trim() === '') return;

    socket.emit('send-message', {
      sender: senderId,
      roomId,
      content: input,
      type: 'text',
    });

    setInput('');
  };

  return (
    <div className="input-bar">
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type something..."
      />
      <button onClick={send}>Send</button>
    </div>
  );
};

export default NewChatInput;
