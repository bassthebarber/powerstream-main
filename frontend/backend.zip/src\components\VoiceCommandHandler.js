// components/VoiceCommandHandler.js

import React, { useEffect } from 'react';

const VoiceCommandHandler = ({ onCommand }) => {
  useEffect(() => {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim();
      console.log('Voice Command:', transcript);
      if (onCommand) {
        onCommand(transcript.toLowerCase());
      }
    };

    recognition.onerror = (e) => {
      console.error('Speech recognition error:', e);
    };

    recognition.start();

    return () => {
      recognition.stop();
    };
  }, [onCommand]);

  return null;
};

export default VoiceCommandHandler;
