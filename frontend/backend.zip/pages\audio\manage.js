// pages/audio/manage.js
import React from 'react';

export default function ManageAudio() {
  return (
    <div className="audio-manage">
      <h1>Manage Audio</h1>
      <p>View and manage uploaded tracks.</p>
      {/* TODO: Connect to /api/audio/manage */}
    </div>
  );
}
