// frontend/components/ChatSidebar.js
import React, { useContext } from 'react';
import { ChatContext } from '../context/chat.context';

const ChatSidebar = () => {
  const { chats, selectChat } = useContext(ChatContext);

  return (
    <div className="chat-sidebar">
      <h2>Conversations</h2>
      <ul>
        {chats.map((chat, index) => (
          <li key={index} onClick={() => selectChat(chat)}>
            <strong>{chat.name}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ChatSidebar;
