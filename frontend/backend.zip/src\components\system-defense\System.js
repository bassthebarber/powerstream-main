import React, { useState } from 'react';

const System = () => {
  const [status, setStatus] = useState('🟢 Operational');

  const handleCheck = () => {
    const rand = Math.random();
    if (rand < 0.2) setStatus('🔴 Fault Detected');
    else setStatus('🟢 Operational');
  };

  return (
    <div className="bg-black text-white p-4 border border-gold rounded">
      <h2 className="text-gold font-bold text-xl mb-2">System Status</h2>
      <p className="text-lg">{status}</p>
      <button
        onClick={handleCheck}
        className="mt-3 bg-gold text-black px-4 py-2 rounded hover:bg-yellow-500"
      >
        Run System Check
      </button>
    </div>
  );
};

export default System;
