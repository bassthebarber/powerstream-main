// CivicUploadWidget.js
import React, { useState } from "react";

export default function CivicUploadWidget({ onUpload }) {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) return;
    setStatus("Uploading...");
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/civic/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("✅ Uploaded!");
        onUpload?.(data);
      } else {
        throw new Error(data.error || "Upload failed");
      }
    } catch (err) {
      setStatus("❌ " + err.message);
    }
  };

  return (
    <div className="civic-upload-widget">
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload} disabled={!file}>
        Upload
      </button>
      {status && <p>{status}</p>}
    </div>
  );
}
