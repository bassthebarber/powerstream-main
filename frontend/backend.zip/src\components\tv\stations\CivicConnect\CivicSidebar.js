// CivicSidebar.js
import React from "react";
import styles from "./CivicModule.css";

export default function CivicSidebar({ onNavigate }) {
  const menu = [
    { label: "CivicPlayer", key: "player" },
    { label: "CivicSchedule", key: "schedule" },
    { label: "CivicCyborg", key: "cyborg" },
    { label: "CivicUpload", key: "upload" },
  ];

  return (
    <div className={styles.container}>
      <h3 className={styles.label}>CivicConnect Panel</h3>
      <ul style={{ listStyle: "none", padding: 0 }}>
        {menu.map((item) => (
          <li
            key={item.key}
            onClick={() => onNavigate(item.key)}
            style={{
              padding: "8px",
              margin: "4px 0",
              background: "#222",
              borderRadius: "6px",
              cursor: "pointer",
              color: "#00aaff",
            }}
          >
            {item.label}
          </li>
        ))}
      </ul>
    </div>
  );
}
