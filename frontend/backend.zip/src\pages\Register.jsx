// frontend/src/pages/Register.jsx
import React, { useState } from "react";
import { api } from "../lib/api.js";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("fiancee@example.com");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setStatus("Creating account...");
    try {
      const data = await api("/auth/register", {
        method: "POST",
        body: JSON.stringify({ name: name.trim(), email: email.trim(), password })
      });
      localStorage.setItem("ps_token", data.token);
      setStatus("✅ Registered & logged in");
      window.location.href = "/feed";
    } catch (e) {
      setStatus(`❌ ${e.message}`);
    }
  }

  return (
    <div style={{ maxWidth: 420, margin: "40px auto", color: "#eee" }}>
      <h2>Create your account</h2>
      <form onSubmit={onSubmit}>
        <div><input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} required style={{width:"100%",padding:8,margin:"8px 0"}}/></div>
        <div><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required style={{width:"100%",padding:8,margin:"8px 0"}}/></div>
        <div><input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required style={{width:"100%",padding:8,margin:"8px 0"}}/></div>
        <button>Sign up</button>
      </form>
      {status && <p style={{marginTop:10}}>{status}</p>}
      <p style={{marginTop:10}}><a href="/login">Already have an account? Log in</a></p>
    </div>
  );
}
