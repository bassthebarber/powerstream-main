// Maps routes to logos using env vars. Falls back to primary.
const ENV = import.meta.env;

const LOGOS = {
  primary: ENV.VITE_LOGO_PRIMARY || "/logos/powerstream-logo.png",

  // Sections
  "/feed": ENV.VITE_LOGO_POWERFEED,
  "/gram": ENV.VITE_LOGO_POWERGRAM,
  "/reel": ENV.VITE_LOGO_POWERREEL,
  "/line": ENV.VITE_LOGO_POWERLINE,

  // Networks
  "/network/southern-power": ENV.VITE_LOGO_SOUTHERN_POWER,
  "/network/texas-got-talent": ENV.VITE_LOGO_TEXAS_GOT_TALENT,
  "/network/no-limit-east-houston": ENV.VITE_LOGO_NO_LIMIT_HOUSTON,
  "/network/civic-connect": ENV.VITE_LOGO_CIVIC_CONNECT,
};

export function logoForPath(pathname) {
  // exact match first
  if (LOGOS[pathname]) return LOGOS[pathname];

  // prefix match (e.g., /network/no-limit-east-houston/uploads)
  const entry = Object.entries(LOGOS).find(([prefix]) =>
    pathname.startsWith(prefix)
  );
  return entry ? entry[1] || LOGOS.primary : LOGOS.primary;
}
