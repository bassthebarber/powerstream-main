import React from "react";
import { apiGet } from "../lib/api";

function StationCard({ s, onPlay }) {
  return (
    <div
      onClick={() => onPlay(s)}
      style={{
        cursor: "pointer",
        background: "#0f0f0f",
        border: "1px solid #222",
        borderRadius: 12,
        overflow: "hidden"
      }}
    >
      <div style={{ aspectRatio: "16/9", background: "#111" }}>
        {s.thumbnail ? (
          <img src={s.thumbnail} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <div style={{ color: "#666", padding: 16 }}>No thumbnail</div>
        )}
      </div>
      <div style={{ padding: 12 }}>
        <div style={{ color: "#d4af37", fontWeight: 700 }}>{s.name}</div>
        <div style={{ color: "#aaa", fontSize: 14 }}>{s.description || ""}</div>
      </div>
    </div>
  );
}

export default function TV() {
  const [stations, setStations] = React.useState([]);
  const [playing, setPlaying] = React.useState(null);
  const [error, setError] = React.useState("");

  React.useEffect(() => {
    (async () => {
      try {
        // try stations first
        const st = await apiGet("/stations");
        if (Array.isArray(st) && st.length) {
          setStations(st);
          return;
        }
        // fallback: build stations from reel/feed posts that have playbackUrl
        const data = await apiGet("/social/posts?channel=reel");
        const hls = (data.posts || []).filter(p => p.playbackUrl).slice(0, 8);
        setStations(hls.map((p, i) => ({
          _id: p._id || `post-${i}`,
          name: p.author || "Live Channel",
          description: p.text || "Live stream",
          playbackUrl: p.playbackUrl,
          thumbnail: p.mediaUrl || null
        })));
      } catch (e) {
        setError(String(e.message || e));
      }
    })();
  }, []);

  return (
    <div style={{ padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      <h2 style={{ color: "#d4af37" }}>PowerTV</h2>

      {playing && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ color: "#ddd", marginBottom: 8, fontWeight: 700 }}>{playing.name}</div>
          <video
            src={playing.playbackUrl}
            controls
            autoPlay
            playsInline
            style={{ width: "100%", borderRadius: 12 }}
          />
        </div>
      )}

      {error && <div style={{ color: "#ff6b6b" }}>{error}</div>}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
        {stations.map(s => (
          <StationCard key={s._id} s={s} onPlay={setPlaying} />
        ))}
      </div>

      {!stations.length && !error && (
        <div style={{ color: "#888", marginTop: 20 }}>No stations found.</div>
      )}
    </div>
  );
}
