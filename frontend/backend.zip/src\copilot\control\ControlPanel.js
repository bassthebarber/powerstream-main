// frontend/src/copilot/control/ControlPanel.js
import React from "react";

const ControlPanel = ({ onCommand, onOverrideToggle, overrideEnabled }) => {
  return (
    <div style={styles.panel}>
      <h3 style={styles.title}>AI Control Panel</h3>
      <button style={styles.button} onClick={() => onCommand("open powerfeed")}>
        Open PowerFeed
      </button>
      <button style={styles.button} onClick={() => onCommand("open powerline")}>
        Open PowerLine
      </button>
      <button style={styles.button} onClick={() => onCommand("start live stream")}>
        Start Live Stream
      </button>
      <button style={styles.button} onClick={() => onCommand("stop live stream")}>
        Stop Live Stream
      </button>
      <button style={styles.overrideButton} onClick={onOverrideToggle}>
        {overrideEnabled ? "Disable Override" : "Enable Override"}
      </button>
    </div>
  );
};

const styles = {
  panel: {
    background: "#111",
    padding: "16px",
    borderRadius: "8px",
    color: "#fff"
  },
  title: {
    marginBottom: "10px"
  },
  button: {
    display: "block",
    background: "#333",
    color: "#fff",
    border: "none",
    padding: "8px 12px",
    margin: "6px 0",
    borderRadius: "4px",
    cursor: "pointer"
  },
  overrideButton: {
    display: "block",
    background: "#ff4d4d",
    color: "#fff",
    border: "none",
    padding: "8px 12px",
    margin: "6px 0",
    borderRadius: "4px",
    cursor: "pointer"
  }
};

export default ControlPanel;
