// frontend/src/components/tv/stations/TexasGotTalent/TGTChat.js
import React, { useState, useEffect, useRef } from "react";
import { io } from "socket.io-client";
import styles from "./tgt.module.css";

const socket = io("http://localhost:5000"); // Change if needed

export default function TGTChat({ username }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const chatEndRef = useRef(null);

  useEffect(() => {
    socket.emit("joinTGT");

    socket.on("oldMessages", (msgs) => {
      setMessages(msgs || []);
    });

    socket.on("chatMessage", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    return () => {
      socket.off("oldMessages");
      socket.off("chatMessage");
    };
  }, []);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    socket.emit("chatMessage", { user: username, text: input });
    setInput("");
  };

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>💬 Fan Chat</h2>
      <div
        style={{
          height: "200px",
          overflowY: "auto",
          background: "#000",
          padding: "8px",
          border: "1px solid #444",
        }}
      >
        {messages.map((m, i) => (
          <div key={i}>
            <strong>{m.user}:</strong> {m.text}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>
      <div style={{ marginTop: "10px" }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Message..."
          style={{ padding: "8px", width: "70%" }}
        />
        <button className={styles.button} onClick={send}>
          Send
        </button>
      </div>
    </div>
  );
}
