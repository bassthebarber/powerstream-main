// pages/search.js
import React from 'react';

export default function SearchPage() {
  return (
    <div className="search-page">
      <h1>Search</h1>
      <p>Find videos, stations, audio, and users.</p>
      {/* TODO: Hook to search API */}
    </div>
  );
}
