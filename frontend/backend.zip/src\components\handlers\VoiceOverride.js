// /core/presentation/voiceOverride.js

let overrideEngaged = false;

export const engageOverride = () => {
  overrideEngaged = true;
  return 'Voice override engaged. Manual protocol enabled.';
};

export const disengageOverride = () => {
  overrideEngaged = false;
  return 'Voice override disengaged. AI resuming control.';
};

export const getOverrideStatus = () => overrideEngaged;
