// components/SpeechPlayer.js

import React, { useEffect } from 'react';

const SpeechPlayer = ({ message }) => {
  useEffect(() => {
    if (!message) return;

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'en-US';
    utterance.pitch = 1;
    utterance.rate = 1;
    utterance.volume = 1;

    window.speechSynthesis.speak(utterance);
  }, [message]);

  return null;
};

export default SpeechPlayer;
