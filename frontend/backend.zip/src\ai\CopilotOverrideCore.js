// frontend/src/ai/CopilotOverrideCore.js
import axios from 'axios';

export default async function runCopilotCommand(command) {
    try {
        const res = await axios.post('/api/copilot/execute', { command });
        return res.data;
    } catch (err) {
        console.error('Copilot Command Error:', err);
        return { error: true, message: 'Command failed' };
    }
}
