import BrainController from './BrainController';
import BrainVoiceController from './BrainVoiceController';

const BrainGlobalController = {
  executeGlobalCommand: (input) => {
    const result = BrainVoiceController.interpretVoice(input);
    console.log("Global Command Result:", result);

    if (input.toLowerCase().includes("reboot")) {
      BrainController.reset();
    }
  }
};

export default BrainGlobalController;
