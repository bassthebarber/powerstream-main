// pages/settings.js
import React from 'react';

export default function SettingsPage() {
  return (
    <div className="settings-page">
      <h1>Account Settings</h1>
      <p>Manage your account details and preferences.</p>
      {/* TODO: Connect to settings API */}
    </div>
  );
}
