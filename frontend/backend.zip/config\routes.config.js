// frontend/config/routes.config.js
export const ROUTES = {
  HOME: '/',
  AUDIO: '/audio',
  VIDEO: '/video',
  FEED: '/feed',
  CHAT: '/chat',
  STREAM: '/stream',
  ADMIN: '/admin',
  DASHBOARD: '/dashboard',
};
