import React from 'react';

const FeedPost = ({ user, content, timestamp }) => {
  return (
    <div className="bg-gray-900 text-white rounded p-4 mb-4 shadow-md">
      <div className="flex items-center mb-2">
        <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full mr-3" />
        <div>
          <h4 className="text-lg font-semibold text-gold">{user.name}</h4>
          <p className="text-sm text-gray-400">{new Date(timestamp).toLocaleString()}</p>
        </div>
      </div>
      <p className="text-white">{content}</p>
    </div>
  );
};

export default FeedPost;
