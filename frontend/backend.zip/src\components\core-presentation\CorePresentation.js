// /core/presentation/corePresentation.js

import React from 'react';

const CorePresentation = ({ systemStatus }) => {
  return (
    <div className="core-presentation">
      <h2>PowerStream Core Status</h2>
      <p>System is currently: <strong>{systemStatus}</strong></p>
    </div>
  );
};

export default CorePresentation;
