// CivicPlayer.js
import React from "react";
import styles from "./CivicModule.css";

export default function CivicPlayer({ streamUrl }) {
  return (
    <div className={styles.container}>
      <h3 className={styles.label}>CivicConnect Live Broadcast</h3>
      <video controls autoPlay muted width="100%" style={{ borderRadius: 10 }}>
        <source src={streamUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
}
