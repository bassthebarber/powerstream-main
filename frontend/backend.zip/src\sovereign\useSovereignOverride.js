// src/sovereign/useSovereignOverride.js
import { useEffect } from 'react';

export default function useSovereignOverride() {
  useEffect(() => {
    console.log("👑 Sovereign Override Activated");
    document.body.style.backgroundColor = "#000";
    document.title = "Sovereign Mode: PowerStream AI";

    // Master override trigger
    window.dispatchEvent(new Event('sovereign-override'));

    return () => {
      document.title = "PowerStream";
    };
  }, []);
}
