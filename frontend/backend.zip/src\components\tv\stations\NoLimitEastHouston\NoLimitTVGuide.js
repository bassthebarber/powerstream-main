import React from "react";
import NoLimitSchedule from "./NoLimitSchedule";

export default function NoLimitTVGuide() {
  return (
    <div>
      <h3>TV Guide</h3>
      <NoLimitSchedule />
    </div>
  );
}
