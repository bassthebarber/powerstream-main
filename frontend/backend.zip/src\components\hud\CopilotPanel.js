// components/HUD/CopilotPanel.js
import React, { useState } from 'react';

export default function CopilotPanel() {
  const [status, setStatus] = useState('Offline');

  const handleActivate = () => {
    setStatus('Active');
    // Optional: Trigger voice or AI logic here
    console.log('Copilot activated.');
  };

  return (
    <div className="copilot-panel">
      <h2>CoPilot System</h2>
      <p>Status: <strong>{status}</strong></p>
      <button onClick={handleActivate}>Activate CoPilot</button>
    </div>
  );
}
