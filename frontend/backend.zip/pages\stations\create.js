// pages/stations/create.js
import React from 'react';

export default function CreateStation() {
  return (
    <div className="create-station">
      <h1>Create a New Station</h1>
      <p>Fill out details to start your station.</p>
      {/* TODO: Hook into station creation API */}
    </div>
  );
}
