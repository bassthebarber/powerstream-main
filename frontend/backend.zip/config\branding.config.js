// frontend/config/branding.config.js
export const BRANDING = {
  logo: '/powerstream-logo.png',
  title: 'PowerStream',
  tagline: 'The Future of Black-Owned TV & Streaming',
};
