// frontend/context/OverrideContext.js
import { createContext, useState } from 'react';

export const OverrideContext = createContext();

export const OverrideProvider = ({ children }) => {
  const [overrideActive, setOverrideActive] = useState(false);

  return (
    <OverrideContext.Provider value={{ overrideActive, setOverrideActive }}>
      {children}
    </OverrideContext.Provider>
  );
};
