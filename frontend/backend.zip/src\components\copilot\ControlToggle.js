import { useState } from 'react';

const ControlToggle = () => {
  const [enabled, setEnabled] = useState(false);

  const handleToggle = () => {
    setEnabled(!enabled);
  };

  return (
    <button onClick={handleToggle}>
      {enabled ? 'Disable Control' : 'Enable Control'}
    </button>
  );
};

export default ControlToggle;
