// src/infinity/InfinityHUD.js
import React from 'react';
import './InfinityHUD.css';

export default function InfinityHUD() {
  return (
    <div className="infinity-hud">
      <span>Status: Online</span>
      <span>Override: Standby</span>
    </div>
  );
}
