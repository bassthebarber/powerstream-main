// AhabOverride.js

import AhabLink from './ahabLink';

export default function AhabOverride(command) {
  if (!command) return 'No command received.';
  const result = AhabLink('override');
  console.log(`[AHAB OVERRIDE] Command "${command}" processed.`);
  return `${result} — Command: ${command}`;
}
