// frontend/context/chat.context.js
import React, { createContext, useState } from 'react';
import useChatSocket from '../hooks/useChatSocket';

export const ChatContext = createContext();

const ChatProvider = ({ children }) => {
  const [chats, setChats] = useState([]);
  const [currentChat, setCurrentChat] = useState(null);

  const onMessageReceived = (message) => {
    if (currentChat) {
      setCurrentChat((prev) => ({
        ...prev,
        messages: [...prev.messages, message],
      }));
    }
  };

  const { sendMessage: socketSend } = useChatSocket(onMessageReceived);

  const sendMessage = (text) => {
    const message = {
      text,
      isMine: true,
      timestamp: new Date().toLocaleTimeString(),
    };
    onMessageReceived(message);
    socketSend(message);
  };

  const selectChat = (chat) => {
    setCurrentChat(chat);
  };

  return (
    <ChatContext.Provider
      value={{
        chats,
        setChats,
        currentChat,
        selectChat,
        sendMessage,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export default ChatProvider;
