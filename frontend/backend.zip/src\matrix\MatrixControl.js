// src/matrix/MatrixControl.js
import React from 'react';

export default function MatrixControl() {
  return (
    <div className="matrix-control">
      <button onClick={() => alert('Matrix Scan Started')}>Start Matrix Scan</button>
      <button onClick={() => alert('Matrix Reset Initiated')}>Reset Matrix</button>
    </div>
  );
}
