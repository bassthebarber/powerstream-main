// frontend/src/copilot/control/AiCommandRouter.js
// Routes AI voice/text commands to the correct feature

const AiCommandRouter = (command, actions) => {
  if (!command || typeof command !== "string") return;

  const cmd = command.toLowerCase();

  // Example command routing
  if (cmd.includes("open powerfeed")) {
    actions.navigate("/powerfeed");
  } else if (cmd.includes("open powerline")) {
    actions.navigate("/powerline");
  } else if (cmd.includes("start live stream")) {
    actions.startLiveStream();
  } else if (cmd.includes("stop live stream")) {
    actions.stopLiveStream();
  } else if (cmd.includes("enable override")) {
    actions.enableOverride();
  } else if (cmd.includes("disable override")) {
    actions.disableOverride();
  } else {
    console.warn(`Unrecognized command: ${command}`);
  }
};

export default AiCommandRouter;
