// frontend/config/permissions.config.js
export const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
  CREATOR: 'creator',
};

export const PERMISSIONS = {
  [ROLES.ADMIN]: ['manage_users', 'view_reports', 'moderate_content'],
  [ROLES.CREATOR]: ['upload_media', 'view_stats'],
  [ROLES.USER]: ['view_content'],
};
