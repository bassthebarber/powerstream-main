// VoiceIntentMapper.js
export const handleVoiceCommand = (text) => {
  const command = text.toLowerCase();

  if (command.includes("upload video")) {
    console.log("🎬 Trigger: Upload Video");
    // Navigate or trigger the AI action here
  }

  if (command.includes("go live")) {
    console.log("📡 Trigger: Go Live Stream");
    // Trigger your stream module
  }

  // Add as many AI actions as you want here...
};
