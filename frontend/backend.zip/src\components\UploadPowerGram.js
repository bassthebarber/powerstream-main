import React, { useState } from 'react';
import axios from 'axios';

const UploadPowerGram = () => {
  const [file, setFile] = useState(null);
  const [caption, setCaption] = useState('');

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('video', file);
    formData.append('caption', caption);

    try {
      await axios.post('/api/upload/powergram', formData);
      alert('PowerGram uploaded!');
    } catch (err) {
      console.error(err);
      alert('Upload failed.');
    }
  };

  return (
    <div className="upload-powergram">
      <h2>Upload to PowerGram</h2>
      <input type="text" placeholder="Caption" onChange={(e) => setCaption(e.target.value)} />
      <input type="file" accept="video/*" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default UploadPowerGram;
