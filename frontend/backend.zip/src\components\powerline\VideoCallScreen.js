import React, { useRef, useEffect } from 'react';
import styles from './VideoCallScreen.module.css';

const VideoCallScreen = ({ onEndCall }) => {
  const localVideoRef = useRef(null);

  useEffect(() => {
    const startVideo = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing media devices.', error);
      }
    };

    startVideo();
    return () => {
      const tracks = localVideoRef.current?.srcObject?.getTracks();
      tracks?.forEach((track) => track.stop());
    };
  }, []);

  return (
    <div className={styles.container}>
      <h2>Video Call in Progress</h2>
      <video ref={localVideoRef} autoPlay playsInline muted className={styles.video} />
      <button className={styles.endBtn} onClick={onEndCall}>End Call</button>
    </div>
  );
};

export default VideoCallScreen;
