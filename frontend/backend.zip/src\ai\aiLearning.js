// ai/aiLearning.js
import { recall, remember } from "./aiMemory";

// Load existing learned commands from memory
let learnedCommands = recall("learnedCommands") || {};

/**
 * Learn a new command mapping
 * @param {string} phrase - The user voice/text command
 * @param {string} action - The AI action or function name
 */
export const learnCommand = (phrase, action) => {
  learnedCommands[phrase.toLowerCase()] = action;
  remember("learnedCommands", learnedCommands);
  console.log(`AI learned: "${phrase}" -> ${action}`);
};

/**
 * Find a learned command by phrase
 * @param {string} phrase
 * @returns {string|null} The mapped action or null
 */
export const findLearnedCommand = (phrase) => {
  return learnedCommands[phrase.toLowerCase()] || null;
};

/**
 * Forget a learned command
 * @param {string} phrase
 */
export const forgetCommand = (phrase) => {
  delete learnedCommands[phrase.toLowerCase()];
  remember("learnedCommands", learnedCommands);
  console.log(`AI forgot command: "${phrase}"`);
};

/**
 * Get all learned commands
 */
export const listLearnedCommands = () => {
  return Object.entries(learnedCommands).map(([phrase, action]) => ({
    phrase,
    action,
  }));
};

// Example self-learning trigger
export const selfLearn = (unrecognizedPhrase) => {
  console.log(`Unrecognized phrase: "${unrecognizedPhrase}"`);
  // Could prompt the user here in UI to map this to an action
};
