// ahab/ahabSync.js
let ahabState = {};
let listeners = [];

export const getAhabState = () => ahabState;

export const setAhabState = (newState) => {
  ahabState = { ...ahabState, ...newState };
  listeners.forEach((cb) => cb(ahabState));
};

export const subscribeToAhab = (callback) => {
  listeners.push(callback);
  return () => {
    listeners = listeners.filter((cb) => cb !== callback);
  };
};

export const syncWithServer = async (serverUrl, token) => {
  try {
    const res = await fetch(`${serverUrl}/api/ahab/sync`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setAhabState(data);
    console.log("AHAB Sync completed:", data);
  } catch (err) {
    console.error("AHAB Sync failed:", err);
  }
};
