// src/pages/PowerGram.jsx
import { useEffect, useState } from 'react';
import api from '../lib/api';

export default function PowerGram() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        // Adjust the endpoint if your backend route differs
        const data = await api.get('/api/gram');
        const list = Array.isArray(data) ? data : (data?.items ?? []);
        if (active) setItems(list);
      } catch (e) {
        if (active) setErr(e.message || 'Failed to load grams');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  if (loading) return <div>Loading PowerGrams…</div>;
  if (err) return <div style={{ color: 'red' }}>Error: {err}</div>;
  if (!items.length) return <div>No posts yet.</div>;

  return (
    <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))' }}>
      {items.map((g) => (
        <article key={g.id || g._id} style={{ border: '1px solid #ddd', borderRadius: 12, padding: 12 }}>
          <h3 style={{ margin: '0 0 8px' }}>{g.title || g.caption || 'Untitled'}</h3>
          {g.image && (
            <img
              src={g.image}
              alt={g.title || 'image'}
              style={{ width: '100%', height: 180, objectFit: 'cover', borderRadius: 8 }}
            />
          )}
          {g.text && <p style={{ marginTop: 8 }}>{g.text}</p>}
        </article>
      ))}
    </div>
  );
}
