import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { apiPost } from "../lib/api";

export default function Login() {
  const nav = useNavigate();
  const loc = useLocation();
  const redirectTo = (loc.state && loc.state.from) || "/feed";

  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true); setError("");
    try {
      // expected backend: POST /api/auth/login {email, password} -> {token, user}
      const data = await apiPost("/auth/login", { email, password });
      localStorage.setItem("ps_jwt", data.token);
      localStorage.setItem("ps_user_email", data?.user?.email || email);
      nav(redirectTo, { replace: true });
    } catch (err) {
      setError(String(err.message || err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ maxWidth: 420, margin: "40px auto", color: "#d4af37" }}>
      <h2>Sign in to PowerStream</h2>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12 }}>
        <label>
          <div>Email</div>
          <input
            type="email"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
            required
            style={{ width: "100%", padding: 10, borderRadius: 8 }}
            placeholder="you@example.com"
          />
        </label>

        <label>
          <div>Password</div>
          <input
            type="password"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
            required
            style={{ width: "100%", padding: 10, borderRadius: 8 }}
            placeholder="••••••••"
          />
        </label>

        {error && <div style={{ color: "#ff6b6b" }}>{error}</div>}

        <button
          disabled={busy}
          style={{
            padding: "10px 14px",
            borderRadius: 10,
            fontWeight: 700,
            background: "#d4af37",
            color: "#000",
            cursor: "pointer",
          }}
        >
          {busy ? "Signing in…" : "Sign In"}
        </button>
      </form>
    </div>
  );
}
