import React, { useEffect, useState } from 'react';

const CPulse = () => {
  const [pulse, setPulse] = useState('🟢 System Stable');

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate status check
      const rand = Math.random();
      if (rand < 0.1) setPulse('🔴 Critical Alert');
      else if (rand < 0.3) setPulse('🟡 Warning');
      else setPulse('🟢 System Stable');
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-white bg-black border border-gold p-4 rounded shadow">
      <h3 className="text-gold font-bold text-xl mb-2">C-Pulse Monitor</h3>
      <p>{pulse}</p>
    </div>
  );
};

export default CPulse;
