import React, { useState, useEffect } from "react";
import socket from "../../../utils/no-limit-socket";
import styles from "./NoLimitStation.module.css";

export default function NoLimitChat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    socket.on("nolimit:chat", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });
    return () => socket.off("nolimit:chat");
  }, []);

  function sendMessage() {
    socket.emit("nolimit:chat", input);
    setInput("");
  }

  return (
    <div className={styles.chat}>
      <h4>Live Chat</h4>
      <div>
        {messages.map((m, i) => (
          <div key={i}>{m}</div>
        ))}
      </div>
      <input value={input} onChange={(e) => setInput(e.target.value)} />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}
