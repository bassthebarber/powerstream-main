// SignalRecovery.js
import { useEffect, useState, useCallback } from 'react';
import useInfinity from './UseInfinity';

export default function SignalRecovery({ reconnectInterval = 5000 }) {
  const { isOnline, runInfinityCommand } = useInfinity();
  const [attempts, setAttempts] = useState(0);

  const attemptReconnect = useCallback(() => {
    console.warn(`⚠️ [SignalRecovery] Attempting reconnection... (${attempts + 1})`);
    runInfinityCommand("reconnectSystem");
    setAttempts(prev => prev + 1);
  }, [attempts, runInfinityCommand]);

  useEffect(() => {
    if (!isOnline) {
      const timer = setInterval(attemptReconnect, reconnectInterval);
      return () => clearInterval(timer);
    } else {
      if (attempts > 0) {
        console.log(`✅ [SignalRecovery] Reconnected after ${attempts} attempts.`);
        runInfinityCommand("stabilizeSignal");
        setAttempts(0);
      }
    }
  }, [isOnline, attemptReconnect, reconnectInterval, attempts, runInfinityCommand]);

  return null; // Headless component
}
