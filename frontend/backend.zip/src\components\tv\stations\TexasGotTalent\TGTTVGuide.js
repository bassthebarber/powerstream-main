import React from "react";
import styles from "./tgt.module.css";

export default function TGTTVGuide() {
  const guide = [
    { time: "6:00 PM", show: "Texas Show Openers" },
    { time: "7:00 PM", show: "Live Talent Battles" },
    { time: "8:30 PM", show: "Community Picks" }
  ];

  return (
    <div className={styles.section}>
      <h2 className={styles.title}>🗓 TV Guide</h2>
      <ul>
        {guide.map((item, index) => (
          <li key={index}>
            <strong>{item.time}</strong> - {item.show}
          </li>
        ))}
      </ul>
    </div>
  );
}
