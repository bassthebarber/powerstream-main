import { useEffect, useRef, useState } from "react";
import { uploadToCloudinary, api } from "../lib/api";
import socket from "../lib/socket";

export default function RecordPage() {
  const [status, setStatus] = useState("Mic ready");
  const [chunks] = useState([]);
  const mediaRef = useRef(null);
  const recRef = useRef(null);
  const meterRef = useRef({ ctx: null, an: null, src: null });
  const barRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createMediaStreamSource(stream);
        const an = ctx.createAnalyser();
        an.fftSize = 256;
        src.connect(an);
        meterRef.current = { ctx, an, src };

        const data = new Uint8Array(an.frequencyBinCount);
        const draw = () => {
          an.getByteTimeDomainData(data);
          let peak = 0;
          for (let i = 0; i < data.length; i++) {
            if (data[i] > peak) peak = data[i];
          }
          const pct = Math.min(100, Math.round((peak / 128) * 100));
          if (barRef.current) {
            barRef.current.style.width = pct + "%";
          }
          requestAnimationFrame(draw);
        };
        draw();

        // MediaRecorder
        const rec = new MediaRecorder(stream);
        rec.ondataavailable = (e) => chunks.push(e.data);
        recRef.current = rec;
        mediaRef.current = stream;
      } catch (e) {
        setStatus("Mic blocked");
      }
    })();

    return () => {
      mediaRef.current?.getTracks()?.forEach((t) => t.stop());
    };
  }, []);

  const onRecord = () => {
    setStatus("Recording…");
    recRef.current?.start();
    socket.emit("record-start");
  };

  const onStop = () => {
    setStatus("Stopped");
    recRef.current?.stop();
    socket.emit("record-stop");
  };

  const onDelete = () => {
    chunks.splice(0, chunks.length);
    setStatus("Deleted track");
  };

  const onSave = async () => {
    if (!chunks.length) return;
    const blob = new Blob(chunks, { type: "audio/webm" });
    const file = new File([blob], "recording.webm", { type: "audio/webm" });

    try {
      const url = await uploadToCloudinary(file);
      setStatus("Uploaded: " + url);
      socket.emit("record-uploaded", { url });
    } catch (err) {
      console.error(err);
      setStatus("Upload failed");
    }
  };

  return (
    <div>
      <h2>Studio Record</h2>
      <div>Status: {status}</div>
      <div
        ref={barRef}
        style={{ width: "0%", height: "10px", background: "green", marginTop: "10px" }}
      />
      <button onClick={onRecord}>Record</button>
      <button onClick={onStop}>Stop</button>
      <button onClick={onDelete}>Delete</button>
      <button onClick={onSave}>Save</button>
    </div>
  );
}
