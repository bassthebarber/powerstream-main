import { useEffect, useState } from "react";
import { api } from "../lib/api"; // your API helper
import "../styles/Library.css"; // optional: create a Library CSS file for styling

export default function Library() {
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchLibrary() {
      try {
        const res = await api.get("/user/library"); // your backend endpoint
        setTracks(res.tracks || []);
      } catch (err) {
        console.error("Failed to fetch library:", err);
        setError("Failed to load your library.");
      } finally {
        setLoading(false);
      }
    }

    fetchLibrary();
  }, []);

  if (loading) return <div className="library-page">Loading library...</div>;
  if (error) return <div className="library-page error">{error}</div>;

  return (
    <div className="library-page">
      <h1>Your Library</h1>
      {tracks.length === 0 ? (
        <p>No tracks found. Upload some beats or recordings to get started!</p>
      ) : (
        <ul className="track-list">
          {tracks.map((track) => (
            <li key={track.id} className="track-item">
              <span className="track-title">{track.title}</span>
              <audio controls src={track.url} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
