// src/pages/Royalty.jsx
import { useEffect, useState } from "react";  
import { sendExportEmail } from "../lib/studioApi"; // correct import
import { listFiles } from "../lib/studioApi"; // if listFiles is defined there

export default function Royalty() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [emailStatus, setEmailStatus] = useState("");

  useEffect(() => {
    async function fetchFiles() {
      try {
        const allFiles = await listFiles(); // this must exist in studioApi.js
        setFiles(allFiles);
      } catch (err) {
        console.error("Error loading files:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchFiles();
  }, []);

  const handleSendEmail = async (fileUrl) => {
    setEmailStatus("Sending...");
    try {
      await sendExportEmail({
        to: "artist@example.com",
        url: fileUrl,
        subject: "Your Studio Export",
        text: "Here is your exported track from the Studio app."
      });
      setEmailStatus("Email sent successfully!");
    } catch (err) {
      console.error(err);
      setEmailStatus("Failed to send email.");
    }
  };

  if (loading) return <p>Loading files...</p>;

  return (
    <div className="royalty-page">
      <h1>Royalty Dashboard</h1>
      {files.length === 0 ? (
        <p>No files uploaded yet.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>File Name</th>
              <th>Preview / Download</th>
              <th>Export Email</th>
            </tr>
          </thead>
          <tbody>
            {files.map((file) => (
              <tr key={file.name}>
                <td>{file.name}</td>
                <td>
                  <a href={file.url} target="_blank" rel="noopener noreferrer">
                    Open
                  </a>
                </td>
                <td>
                  <button onClick={() => handleSendEmail(file.url)}>Send Email</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {emailStatus && <p>Status: {emailStatus}</p>}
    </div>
  );
}
