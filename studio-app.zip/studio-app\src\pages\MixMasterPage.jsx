import { useState } from "react";
const API = import.meta.env.VITE_STUDIO_API || "https://studio.southernpowertvmusic.com/api";

export default function MixMasterPage(){
  const [file,setFile]=useState(null); const [status,setStatus]=useState(""); const [url,setUrl]=useState("");
  const submit=async(e)=>{ e.preventDefault(); if(!file) return;
    setStatus("Processing…");
    const form=new FormData(); form.append("file", file);
    const r=await fetch(`${API}/process/mixmaster`,{method:"POST",body:form});
    const d=await r.json().catch(()=>({})); if(!r.ok){ setStatus(d.message||"Error"); return; }
    setUrl(d.url); setStatus("✅ Done");
  };
  return (
    <section style={s.wrap}>
      <h2 style={s.h2}>Mix / Master (auto-loudness + clean)</h2>
      <form onSubmit={submit} style={s.card}>
        <input type="file" accept="audio/*" onChange={e=>setFile(e.target.files?.[0]||null)} />
        <button style={s.btn}>Process</button>
      </form>
      {status && <div style={{marginTop:8}}>{status}</div>}
      {url && <audio controls src={url} style={{width:"100%",marginTop:10}}/>}
    </section>
  );
}
const s={wrap:{background:"#000",color:"#f5d76e",padding:16},h2:{marginTop:0},
card:{background:"#0b0b0b",border:"1px solid #3a2c00",borderRadius:12,padding:12,display:"flex",gap:10,alignItems:"center"},
btn:{background:"#f5d76e",color:"#000",border:"none",padding:"8px 12px",borderRadius:10,fontWeight:800,cursor:"pointer"}};
