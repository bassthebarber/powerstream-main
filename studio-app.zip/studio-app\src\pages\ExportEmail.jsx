import React from "react";
import ExportBoard from "../components/ExportBoard.jsx";

export default function ExportEmail() {
  return (
    <div>
      <h1>Export Email</h1>
      <p>Send your projects or recordings via email.</p>
      <ExportBoard />
    </div>
  );
}
