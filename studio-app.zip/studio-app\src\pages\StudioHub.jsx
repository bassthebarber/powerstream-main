import { Link } from "react-router-dom";

export default function StudioHub(){
  return (
    <div className="page-wrap">
      <h1 className="h1">Southern Power Syndicate · No Limit East Houston</h1>
      <div className="subtitle">AI Recording Studio</div>

      <div className="tile-grid">
        <div className="tile"><Link to="/record">Record (Mic Booth)</Link></div>
        <div className="tile"><Link to="/mix">Mix &amp; Master</Link></div>
        <div className="tile"><Link to="/beats">Beat Store / Beat Player</Link></div>
        <div className="tile"><Link to="/royalty">Royalty Splits</Link></div>
        <div className="tile"><Link to="/upload">Upload Tracks</Link></div>
        <div className="tile"><Link to="/visualizer">Master Track Visualizer</Link></div>
      </div>
    </div>
  );
}
