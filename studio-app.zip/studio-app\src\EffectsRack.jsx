// EffectsRack.jsx
import React from 'react';


export default function EffectsRack() {
return (
<div className="effects-rack">
<h2>🎛️ Effects Rack</h2>
<p>Add reverb, delay, EQ, and more using AI-powered audio effects.</p>
</div>
);
}