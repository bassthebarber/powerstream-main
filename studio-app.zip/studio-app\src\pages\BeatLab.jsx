import { useState, useRef } from "react";
import { uploadToCloudinary, postJSON } from "../lib/api";

export default function BeatLab() {
  const [beats, setBeats] = useState([]);
  const audioRef = useRef();

  const handleUpload = async (file) => {
    if (!file) return;
    try {
      const result = await uploadToCloudinary(file); // upload file to Cloudinary
      setBeats((prev) => [...prev, result]);         // add uploaded beat to state
    } catch (err) {
      console.error("Upload failed:", err);
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>BeatLab</h1>
      <input
        type="file"
        accept="audio/*"
        onChange={(e) => handleUpload(e.target.files[0])}
      />
      <ul style={{ marginTop: "2rem" }}>
        {beats.map((beat, i) => (
          <li key={i}>
            <p>{beat.name || `Beat ${i + 1}`}</p>
            <audio ref={audioRef} src={beat.url} controls />
          </li>
        ))}
      </ul>
    </div>
  );
}
