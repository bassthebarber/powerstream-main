import { useEffect, useState } from "react";
const API = import.meta.env.VITE_STUDIO_API || "https://studio.southernpowertvmusic.com/api";

export default function BeatStorePage(){
  const [beats,setBeats]=useState([]); const [err,setErr]=useState("");
  useEffect(()=>{ (async()=>{
    try{ const r=await fetch(`${API}/beats`); const d=await r.json(); setBeats(d.beats||[]); }
    catch(e){ setErr("Could not load beats."); }
  })(); },[]);
  return (
    <section style={s.wrap}>
      <h2 style={s.h2}>Beat Store</h2>
      {err && <div>{err}</div>}
      <div style={s.list}>
        {beats.map(b=>(
          <div key={b.id} style={s.card}>
            <strong>{b.title}</strong> · <span>{b.bpm} BPM</span>
            <audio controls src={b.url} style={{width:"100%",marginTop:8}}/>
          </div>
        ))}
      </div>
      <hr style={{opacity:.1,margin:"22px 0"}}/>
      <h3>Quick Generator (client-side demo)</h3>
      <p style={{opacity:.8}}>Tap to hear a generated loop (for fun). For real AI beats, we’ll hook your server later.</p>
      <button style={s.btn} onClick={()=>new Audio("https://actions.google.com/sounds/v1/cartoon/wood_plank_flicks.ogg").play()}>Generate Loop</button>
    </section>
  );
}
const s={wrap:{background:"#000",color:"#f5d76e",padding:16},h2:{marginTop:0},
list:{display:"grid",gap:12},card:{background:"#0b0b0b",border:"1px solid #3a2c00",borderRadius:12,padding:12},
btn:{background:"#f5d76e",color:"#000",border:"none",padding:"10px 14px",borderRadius:12,fontWeight:800,cursor:"pointer"}};
