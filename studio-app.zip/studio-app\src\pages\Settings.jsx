// src/pages/Settings.jsx
import { useEffect, useState } from "react";
import { getStudioStats } from "../lib/studioApi.js";

export default function Settings() {
  const [theme, setTheme] = useState("dark");
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [latency, setLatency] = useState(128);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Fetch studio stats from backend
  useEffect(() => {
    async function fetchStats() {
      try {
        const data = await getStudioStats();
        setStats(data);
      } catch (err) {
        console.error("Failed to load stats:", err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchStats();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      // pretend to save settings to backend
      await new Promise((r) => setTimeout(r, 800));
      alert("Settings saved successfully!");
    } catch (err) {
      alert("Failed to save settings: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-6 text-gray-400">Loading settings...</div>;
  }

  return (
    <div className="p-6 text-white bg-black min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-yellow-400">Studio Settings</h1>

      <div className="bg-gray-900 p-4 rounded-xl shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-2">Theme</h2>
        <select
          value={theme}
          onChange={(e) => setTheme(e.target.value)}
          className="bg-gray-800 text-white px-3 py-2 rounded-lg w-full"
        >
          <option value="dark">Dark Mode</option>
          <option value="light">Light Mode</option>
        </select>
      </div>

      <div className="bg-gray-900 p-4 rounded-xl shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-2">Audio Latency (ms)</h2>
        <input
          type="range"
          min="64"
          max="512"
          step="64"
          value={latency}
          onChange={(e) => setLatency(e.target.value)}
          className="w-full accent-yellow-500"
        />
        <p className="text-gray-400 mt-2">{latency} ms</p>
      </div>

      <div className="bg-gray-900 p-4 rounded-xl shadow-md mb-6 flex items-center justify-between">
        <h2 className="text-xl font-semibold">Email Alerts</h2>
        <label className="flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={emailAlerts}
            onChange={(e) => setEmailAlerts(e.target.checked)}
            className="hidden"
          />
          <div
            className={`w-10 h-5 flex items-center bg-gray-700 rounded-full p-1 duration-300 ease-in-out ${
              emailAlerts ? "bg-yellow-500" : "bg-gray-600"
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${
                emailAlerts ? "translate-x-5" : ""
              }`}
            />
          </div>
        </label>
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-5 py-3 rounded-xl shadow-md transition-all"
      >
        {saving ? "Saving..." : "Save Settings"}
      </button>

      {stats && (
        <div className="mt-10 bg-gray-900 p-4 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold mb-2 text-yellow-400">Studio Stats</h2>
          <ul className="text-gray-300 space-y-1">
            <li>Total Files: {stats.totalFiles ?? "—"}</li>
            <li>Total Exports: {stats.totalExports ?? "—"}</li>
            <li>Last Process: {stats.lastProcess ?? "—"}</li>
          </ul>
        </div>
      )}
    </div>
  );
}
