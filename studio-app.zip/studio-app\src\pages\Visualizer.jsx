// src/pages/Visualizer.jsx
import { useEffect, useRef } from "react";

export default function Visualizer() {
  const canvasRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    async function setupVisualizer() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        source.connect(analyser);

        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        function draw() {
          requestAnimationFrame(draw);
          analyser.getByteFrequencyData(dataArray);

          ctx.fillStyle = "#000";
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          const barWidth = canvas.width / bufferLength * 2.5;
          let x = 0;

          for (let i = 0; i < bufferLength; i++) {
            const barHeight = dataArray[i] / 2;
            ctx.fillStyle = `rgb(${barHeight + 100},50,${255 - barHeight})`;
            ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
            x += barWidth + 1;
          }
        }

        draw();
      } catch (e) {
        console.error("Microphone access denied:", e);
      }
    }

    setupVisualizer();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Audio Visualizer</h1>
      <canvas
        ref={canvasRef}
        width={800}
        height={300}
        className="border border-gray-300 w-full"
      />
    </div>
  );
}
