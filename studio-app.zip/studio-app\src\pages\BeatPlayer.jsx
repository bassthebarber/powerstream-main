import { useMemo, useRef, useState } from "react";

/**
 * Super-simple pad player with BPM.
 * You can drop your own pad sounds (mp3/wav) by editing the URL list below.
 */
const DEFAULT_SAMPLES = [
  { name: "Kick", url: "https://actions.google.com/sounds/v1/alarms/beep_short.ogg" },
  { name: "Snare", url: "https://actions.google.com/sounds/v1/cartoon/cartoon_boing.ogg" },
  { name: "Hat", url: "https://actions.google.com/sounds/v1/cartoon/wood_plank_flicks.ogg" },
  { name: "808", url: "https://actions.google.com/sounds/v1/alarms/beep_short.ogg" },
];

export default function BeatPlayer() {
  const [bpm, setBpm] = useState(90);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRefs = useMemo(
    () => DEFAULT_SAMPLES.map(() => new Audio()),
    []
  );
  const stepRef = useRef(0);
  const timerRef = useRef(null);
  const [grid, setGrid] = useState(() =>
    Array.from({ length: 16 }, () => DEFAULT_SAMPLES.map(() => false))
  );

  const playPad = (i) => {
    const a = audioRefs[i];
    a.src = DEFAULT_SAMPLES[i].url;
    a.currentTime = 0;
    a.play().catch(() => {});
  };

  const toggleCell = (step, pad) => {
    setGrid((g) => {
      const copy = g.map((row) => [...row]);
      copy[step][pad] = !copy[step][pad];
      return copy;
    });
  };

  const start = () => {
    if (isPlaying) return;
    setIsPlaying(true);
    const interval = (60 / bpm) * 250; // 1/4 note
    timerRef.current = setInterval(() => {
      const step = stepRef.current % 16;
      grid[step].forEach((on, padIdx) => on && playPad(padIdx));
      stepRef.current = step + 1;
    }, interval);
  };

  const stop = () => {
    setIsPlaying(false);
    clearInterval(timerRef.current);
    timerRef.current = null;
    stepRef.current = 0;
  };

  return (
    <div style={s.wrap}>
      <h2 style={s.h2}>Beat Player · Pads + BPM</h2>
      <div style={s.controls}>
        <label>BPM:&nbsp;
          <input
            type="number"
            min={60}
            max={180}
            value={bpm}
            onChange={(e) => setBpm(Number(e.target.value))}
            style={s.input}
          />
        </label>
        {!isPlaying ? (
          <button style={s.btn} onClick={start}>▶️ Play</button>
        ) : (
          <button style={s.btnWarn} onClick={stop}>⏹ Stop</button>
        )}
      </div>

      <div style={s.grid}>
        {grid.map((row, step) => (
          <div key={step} style={s.row}>
            {row.map((on, pad) => (
              <button
                key={`${step}-${pad}`}
                onClick={() => toggleCell(step, pad)}
                style={{...s.cell, background: on ? "#f5d76e" : "#1b1b1b"}}
                title={`${DEFAULT_SAMPLES[pad].name} — step ${step+1}`}
              />
            ))}
          </div>
        ))}
      </div>

      <div style={s.padRow}>
        {DEFAULT_SAMPLES.map((p, i) => (
          <button key={p.name} style={s.pad} onClick={() => playPad(i)}>
            {p.name}
          </button>
        ))}
      </div>
    </div>
  );
}

const s = {
  wrap:{ background:"#000", color:"#f5d76e", padding:16, border:"1px solid #3a2c00", borderRadius:14 },
  h2:{ marginTop:0 },
  controls:{ display:"flex", alignItems:"center", gap:12, marginBottom:10 },
  input:{ width:72, padding:"6px 8px", background:"#0b0b0b", color:"#f5d76e", border:"1px solid #3a2c00", borderRadius:8 },
  btn:{ background:"#d4af37", color:"#000", border:"none", padding:"8px 14px", borderRadius:10, cursor:"pointer", fontWeight:800 },
  btnWarn:{ background:"#ff5c5c", color:"#000", border:"none", padding:"8px 14px", borderRadius:10, cursor:"pointer", fontWeight:800 },
  grid:{ display:"grid", gridTemplateRows:"repeat(16,28px)", gap:6, marginTop:10 },
  row:{ display:"grid", gridTemplateColumns:"repeat(4,28px)", gap:6 },
  cell:{ width:28, height:28, border:"1px solid #3a2c00", borderRadius:6, cursor:"pointer" },
  padRow:{ display:"flex", gap:10, marginTop:14 },
  pad:{ background:"#f5d76e", color:"#000", padding:"10px 14px", border:"none", borderRadius:10, fontWeight:800, cursor:"pointer" }
};
