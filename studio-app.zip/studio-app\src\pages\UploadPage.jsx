// src/pages/UploadPage.jsx
import React, { useState } from "react";
import UploadWidget from "../components/UploadWidget.jsx";
import { api } from "../lib/api.js";

export default function UploadPage() {
  const [files, setFiles] = useState([]);

  const handleUpload = async (file) => {
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await api.post("/uploads", formData); // make sure your backend route exists
      console.log("Upload complete:", res.data);

      setFiles((prev) => [...prev, res.data]);
    } catch (err) {
      console.error("Upload failed:", err);
    }
  };

  return (
    <div>
      <h1>Upload Files</h1>
      <UploadWidget onUpload={handleUpload} />
      <ul>
        {files.map((f, i) => (
          <li key={i}>{f.filename || f.url}</li>
        ))}
      </ul>
    </div>
  );
}
